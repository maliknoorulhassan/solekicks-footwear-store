export type ShoeCategory = 'All' | 'Running' | 'Basketball' | 'Lifestyle' | 'Retro' | 'Classics';

export interface ShoeColorway {
  name: string;
  hex: string;
  badgeClass?: string;
}

export interface Product {
  id: string;
  name: string;
  brand: 'Nike' | 'Adidas' | 'Jordan' | 'New Balance' | 'Puma' | 'On Running' | 'Asics';
  category: ShoeCategory;
  price: number;
  originalPrice?: number;
  rating: number;
  reviewCount: number;
  inStock: number;
  isNew?: boolean;
  isTrending?: boolean;
  isFeatured?: boolean;
  colors: ShoeColorway[];
  sizes: number[];
  heroImage: string;
  gallery: string[];
  description: string;
  specs: {
    cushioning: string;
    upperMaterial: string;
    weight: string;
    closure: string;
  };
}

export interface CartItem {
  id: string; // Composite unique key: `${productId}-${selectedSize}-${selectedColor}`
  product: Product;
  selectedSize: number;
  selectedColor: string;
  quantity: number;
}

export interface PromoCode {
  code: string;
  discountPercent: number;
  minSpend?: number;
  description: string;
}

export interface CartTotals {
  subtotal: number;
  discountAmount: number;
  shipping: number;
  tax: number;
  total: number;
  itemsCount: number;
  freeShippingQualified: boolean;
  amountNeededForFreeShipping: number;
}

export interface ProductFilters {
  category: ShoeCategory;
  brand: string;
  search: string;
  maxPrice: number;
  sort: 'featured' | 'price-asc' | 'price-desc' | 'rating' | 'newest';
  selectedSize?: number | null;
}

export interface ShippingAddress {
  fullName: string;
  email: string;
  phone: string;
  street: string;
  city: string;
  postalCode: string;
  country: string;
}

export interface Order {
  id: string;
  createdAt: string;
  items: CartItem[];
  totals: CartTotals;
  shippingAddress: ShippingAddress;
  paymentMethod: 'card' | 'applepay' | 'cod';
  status: 'Confirmed' | 'Packing' | 'Shipped' | 'Out for Delivery' | 'Delivered';
  trackingNumber: string;
  estimatedDelivery: string;
}
