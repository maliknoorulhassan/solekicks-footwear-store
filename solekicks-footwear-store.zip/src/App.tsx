import React, { useState, useMemo, useEffect } from 'react';
import { INITIAL_PRODUCTS } from './data/products';
import { Product, CartItem, ProductFilters, PromoCode, Order, ShoeCategory } from './types';
import { calculateCartTotals, filterAndSortProducts, PROMO_CODES } from './utils/cart';
import { Navbar } from './components/Navbar';
import { HeroBanner } from './components/HeroBanner';
import { CategoryAndFilterBar } from './components/CategoryAndFilterBar';
import { ProductCard } from './components/ProductCard';
import { ProductDetailModal } from './components/ProductDetailModal';
import { CartDrawer } from './components/CartDrawer';
import { CheckoutModal } from './components/CheckoutModal';
import { WishlistDrawer } from './components/WishlistDrawer';
import { OrdersDrawer } from './components/OrdersDrawer';
import { FloatingCartButton } from './components/FloatingCartButton';
import { BottomNav } from './components/BottomNav';
import { ConfettiCanvas } from './components/ConfettiCanvas';
import { Footprints, ShieldCheck, RefreshCw, Sparkles } from 'lucide-react';

export default function App() {
  // Products & Filters State
  const [products] = useState<Product[]>(INITIAL_PRODUCTS);
  const [filters, setFilters] = useState<ProductFilters>({
    category: 'All',
    brand: 'All',
    search: '',
    maxPrice: 300,
    sort: 'featured',
    selectedSize: null,
  });

  // Cart State (with initial sample item for delightful first impression, plus localStorage backup)
  const [cart, setCart] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('solekicks_cart');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      // ignore
    }
    // Seed with 1 popular shoe for immediate gratification
    const seed = INITIAL_PRODUCTS[0];
    return [
      {
        id: `${seed.id}-10-${seed.colors[0].name}`,
        product: seed,
        selectedSize: 10,
        selectedColor: seed.colors[0].name,
        quantity: 1,
      },
    ];
  });

  // Wishlist State
  const [wishlist, setWishlist] = useState<Product[]>(() => {
    try {
      const saved = localStorage.getItem('solekicks_wishlist');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      // ignore
    }
    return [INITIAL_PRODUCTS[1]]; // seed with 1 item
  });

  // Orders State
  const [orders, setOrders] = useState<Order[]>(() => {
    try {
      const saved = localStorage.getItem('solekicks_orders');
      if (saved) return JSON.parse(saved);
    } catch (e) {
      // ignore
    }
    return [];
  });

  // UI Modals & Drawers State
  const [appliedPromo, setAppliedPromo] = useState<PromoCode | null>(PROMO_CODES['KICKS20']);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [isDetailModalOpen, setIsDetailModalOpen] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);
  const [isOrdersOpen, setIsOrdersOpen] = useState(false);
  const [isCheckoutOpen, setIsCheckoutOpen] = useState(false);
  const [showConfetti, setShowConfetti] = useState(false);
  const [activeMobileTab, setActiveMobileTab] = useState<'home' | 'catalog' | 'wishlist' | 'cart' | 'orders'>('home');

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('solekicks_cart', JSON.stringify(cart));
    } catch (e) {}
  }, [cart]);

  useEffect(() => {
    try {
      localStorage.setItem('solekicks_wishlist', JSON.stringify(wishlist));
    } catch (e) {}
  }, [wishlist]);

  useEffect(() => {
    try {
      localStorage.setItem('solekicks_orders', JSON.stringify(orders));
    } catch (e) {}
  }, [orders]);

  // Derived Totals
  const cartTotals = useMemo(() => {
    return calculateCartTotals(cart, appliedPromo);
  }, [cart, appliedPromo]);

  // Filtered Products
  const filteredProducts = useMemo(() => {
    return filterAndSortProducts(products, filters);
  }, [products, filters]);

  // Cart Operations
  const handleAddToCart = (
    product: Product,
    selectedSize: number,
    selectedColor: string,
    quantity: number = 1
  ) => {
    const compositeId = `${product.id}-${selectedSize}-${selectedColor}`;
    setCart((prev) => {
      const existingIndex = prev.findIndex((item) => item.id === compositeId);
      if (existingIndex > -1) {
        const next = [...prev];
        next[existingIndex] = {
          ...next[existingIndex],
          quantity: next[existingIndex].quantity + quantity,
        };
        return next;
      } else {
        return [
          ...prev,
          {
            id: compositeId,
            product,
            selectedSize,
            selectedColor,
            quantity,
          },
        ];
      }
    });
  };

  const handleUpdateCartQuantity = (id: string, delta: number) => {
    setCart((prev) => {
      return prev
        .map((item) => {
          if (item.id === id) {
            const nextQty = item.quantity + delta;
            return nextQty > 0 ? { ...item, quantity: nextQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[];
    });
  };

  const handleRemoveFromCart = (id: string) => {
    setCart((prev) => prev.filter((item) => item.id !== id));
  };

  // Instant Buy Now
  const handleBuyNow = (
    product: Product,
    selectedSize: number,
    selectedColor: string,
    quantity: number = 1
  ) => {
    handleAddToCart(product, selectedSize, selectedColor, quantity);
    setIsDetailModalOpen(false);
    setIsCheckoutOpen(true);
  };

  // Wishlist Operations
  const handleToggleWishlist = (product: Product) => {
    setWishlist((prev) => {
      const exists = prev.some((p) => p.id === product.id);
      if (exists) {
        return prev.filter((p) => p.id !== product.id);
      } else {
        return [...prev, product];
      }
    });
  };

  const handleOpenDetailModal = (product: Product) => {
    setSelectedProduct(product);
    setIsDetailModalOpen(true);
  };

  const handleOrderPlaced = (order: Order) => {
    setOrders((prev) => [order, ...prev]);
    setCart([]); // Clear cart
    setShowConfetti(true);
    setTimeout(() => setShowConfetti(false), 4500);
  };

  const scrollToCatalog = () => {
    setActiveMobileTab('catalog');
    const el = document.getElementById('catalog-section');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleResetFilters = () => {
    setFilters({
      category: 'All',
      brand: 'All',
      search: '',
      maxPrice: 300,
      sort: 'featured',
      selectedSize: null,
    });
  };

  return (
    <div className="min-h-screen bg-neutral-50 text-neutral-900 flex flex-col selection:bg-red-500 selection:text-white pb-20 md:pb-10">
      {/* Confetti Animation when orders are placed */}
      <ConfettiCanvas active={showConfetti} />

      {/* Colorful Styled Navbar */}
      <Navbar
        cartCount={cartTotals.itemsCount}
        cartTotal={cartTotals.total}
        wishlistCount={wishlist.length}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenWishlist={() => setIsWishlistOpen(true)}
        onOpenOrders={() => setIsOrdersOpen(true)}
        searchQuery={filters.search}
        onSearchChange={(search) => setFilters((prev) => ({ ...prev, search }))}
        activeCategory={filters.category}
        onSelectCategory={(category) => setFilters((prev) => ({ ...prev, category }))}
      />

      <main className="flex-1">
        {/* Hero Section */}
        <HeroBanner
          onShopNow={scrollToCatalog}
          onExploreBrand={(brand) => {
            setFilters((prev) => ({ ...prev, brand }));
            scrollToCatalog();
          }}
        />

        {/* Catalog Section */}
        <section id="catalog-section" className="container mx-auto px-4 sm:px-6 lg:px-8 py-6">
          {/* Section Header */}
          <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-4 gap-2">
            <div>
              <div className="flex items-center gap-1.5 text-xs font-bold text-red-600 uppercase tracking-widest">
                <Sparkles className="w-4 h-4 text-amber-500" />
                <span>Premium Footwear Collection</span>
              </div>
              <h2 className="font-display text-2xl sm:text-3xl font-black text-neutral-900 tracking-tight">
                {filters.category === 'All' ? 'Latest Sneakers & Kicks' : `${filters.category} Collection`}
              </h2>
            </div>
            {filters.search && (
              <span className="text-xs text-neutral-500">
                Search results for: <strong className="text-neutral-900">"{filters.search}"</strong>
              </span>
            )}
          </div>

          {/* Filter Bar with Categories, Brands, Sizes & Sort */}
          <CategoryAndFilterBar
            filters={filters}
            onChangeFilters={(updated) => setFilters((prev) => ({ ...prev, ...updated }))}
            onResetFilters={handleResetFilters}
            totalResults={filteredProducts.length}
          />

          {/* Products Responsive Grid */}
          {filteredProducts.length === 0 ? (
            <div className="text-center py-20 px-4 bg-white rounded-3xl border border-neutral-200 shadow-xs">
              <div className="w-16 h-16 bg-red-50 text-red-600 rounded-full flex items-center justify-center mx-auto mb-4">
                <Footprints className="w-8 h-8" />
              </div>
              <h3 className="font-display font-bold text-lg text-neutral-800">No sneakers found</h3>
              <p className="text-xs text-neutral-500 max-w-sm mx-auto mt-1 mb-4">
                We couldn't find any footwear matching your exact filters. Try clearing some filters or searching for another model.
              </p>
              <button
                onClick={handleResetFilters}
                className="px-5 py-2.5 rounded-xl bg-neutral-900 hover:bg-red-600 text-white font-bold text-xs transition-colors cursor-pointer"
              >
                Reset All Filters
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-6">
              {filteredProducts.map((product) => (
                <ProductCard
                  key={product.id}
                  product={product}
                  isWishlisted={wishlist.some((p) => p.id === product.id)}
                  onToggleWishlist={handleToggleWishlist}
                  onSelectProduct={handleOpenDetailModal}
                  onQuickAddToCart={(prod, size, color) => handleAddToCart(prod, size, color, 1)}
                />
              ))}
            </div>
          )}
        </section>

        {/* Brand Showcase Section */}
        <section className="container mx-auto px-4 sm:px-6 lg:px-8 py-10 mt-6 border-t border-neutral-200">
          <div className="text-center max-w-xl mx-auto mb-8">
            <h3 className="font-display text-xl sm:text-2xl font-black text-neutral-900">
              Authorized Authenticated Footwear
            </h3>
            <p className="text-xs text-neutral-500 mt-1">
              Every sneaker is inspected by our team of certified specialists before packing and delivery.
            </p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
            <div className="bg-white p-4 rounded-2xl border border-neutral-200/80 shadow-xs">
              <div className="w-10 h-10 rounded-xl bg-red-100 text-red-600 flex items-center justify-center mx-auto mb-2">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-xs text-neutral-900">100% Verified</h4>
              <p className="text-[11px] text-neutral-500 mt-0.5">Physical authentication check</p>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-neutral-200/80 shadow-xs">
              <div className="w-10 h-10 rounded-xl bg-amber-100 text-amber-600 flex items-center justify-center mx-auto mb-2">
                <Sparkles className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-xs text-neutral-900">Curated Vault</h4>
              <p className="text-[11px] text-neutral-500 mt-0.5">Deadstock & limited retro drops</p>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-neutral-200/80 shadow-xs">
              <div className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto mb-2">
                <Footprints className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-xs text-neutral-900">True To Size</h4>
              <p className="text-[11px] text-neutral-500 mt-0.5">Precise sizing & fitting advice</p>
            </div>

            <div className="bg-white p-4 rounded-2xl border border-neutral-200/80 shadow-xs">
              <div className="w-10 h-10 rounded-xl bg-blue-100 text-blue-600 flex items-center justify-center mx-auto mb-2">
                <RefreshCw className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-xs text-neutral-900">30-Day Hassle Free</h4>
              <p className="text-[11px] text-neutral-500 mt-0.5">Free exchange on unworn kicks</p>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-neutral-950 text-white pt-10 pb-20 md:pb-10 border-t border-neutral-800">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 border-b border-neutral-800 pb-8">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-red-600 text-white flex items-center justify-center">
                <Footprints className="w-5 h-5 stroke-[2.5]" />
              </div>
              <span className="font-display font-extrabold text-xl tracking-tight">
                SOLE<span className="text-amber-400">KICKS</span>
              </span>
            </div>
            <p className="text-xs text-neutral-400 text-center sm:text-right">
              Crafted for footwear lovers worldwide. All sneaker imagery in high definition.
            </p>
          </div>
          <div className="pt-6 flex flex-col sm:flex-row items-center justify-between text-neutral-500 text-[11px] gap-2">
            <span>© {new Date().getFullYear()} SoleKicks Footwear Studio. All rights reserved.</span>
            <div className="flex items-center gap-4">
              <span className="hover:text-white cursor-pointer">Terms of Service</span>
              <span className="hover:text-white cursor-pointer">Privacy Policy</span>
              <span className="hover:text-white cursor-pointer">Authenticity Guarantee</span>
            </div>
          </div>
        </div>
      </footer>

      {/* Floating Action Button for Quick Cart (explicit user requirement) */}
      <FloatingCartButton
        cartCount={cartTotals.itemsCount}
        cartTotal={cartTotals.total}
        onOpenCart={() => setIsCartOpen(true)}
      />

      {/* Bottom Navigation Bar for Mobile Quick Access to Cart (explicit user requirement) */}
      <BottomNav
        cartCount={cartTotals.itemsCount}
        cartTotal={cartTotals.total}
        wishlistCount={wishlist.length}
        activeTab={activeMobileTab}
        onNavigateHome={() => {
          setActiveMobileTab('home');
          handleResetFilters();
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        onNavigateCatalog={() => {
          scrollToCatalog();
        }}
        onOpenWishlist={() => {
          setActiveMobileTab('wishlist');
          setIsWishlistOpen(true);
        }}
        onOpenCart={() => {
          setActiveMobileTab('cart');
          setIsCartOpen(true);
        }}
        onOpenOrders={() => {
          setActiveMobileTab('orders');
          setIsOrdersOpen(true);
        }}
      />

      {/* Slide-over & Modal Overlays */}
      <ProductDetailModal
        product={selectedProduct}
        isOpen={isDetailModalOpen}
        onClose={() => setIsDetailModalOpen(false)}
        isWishlisted={selectedProduct ? wishlist.some((p) => p.id === selectedProduct.id) : false}
        onToggleWishlist={handleToggleWishlist}
        onAddToCart={handleAddToCart}
        onBuyNow={handleBuyNow}
      />

      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cart}
        totals={cartTotals}
        appliedPromo={appliedPromo}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveFromCart}
        onApplyPromo={setAppliedPromo}
        onProceedToCheckout={() => {
          setIsCartOpen(false);
          setIsCheckoutOpen(true);
        }}
        onExploreFootwear={scrollToCatalog}
      />

      <CheckoutModal
        isOpen={isCheckoutOpen}
        onClose={() => setIsCheckoutOpen(false)}
        items={cart}
        totals={cartTotals}
        onOrderPlaced={handleOrderPlaced}
      />

      <WishlistDrawer
        isOpen={isWishlistOpen}
        onClose={() => setIsWishlistOpen(false)}
        wishlist={wishlist}
        onRemoveFromWishlist={handleToggleWishlist}
        onSelectProduct={handleOpenDetailModal}
        onAddToCart={(prod, size, color) => {
          handleAddToCart(prod, size, color, 1);
          setIsCartOpen(true);
        }}
      />

      <OrdersDrawer
        isOpen={isOrdersOpen}
        onClose={() => setIsOrdersOpen(false)}
        orders={orders}
      />
    </div>
  );
}
