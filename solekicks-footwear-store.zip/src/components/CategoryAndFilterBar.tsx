import React from 'react';
import { CATEGORIES, BRANDS } from '../data/products';
import { ShoeCategory, ProductFilters } from '../types';
import { SlidersHorizontal, RotateCcw } from 'lucide-react';

interface CategoryAndFilterBarProps {
  filters: ProductFilters;
  onChangeFilters: (filters: Partial<ProductFilters>) => void;
  onResetFilters: () => void;
  totalResults: number;
}

const COMMON_SIZES = [7, 7.5, 8, 8.5, 9, 9.5, 10, 10.5, 11, 11.5, 12];

export const CategoryAndFilterBar: React.FC<CategoryAndFilterBarProps> = ({
  filters,
  onChangeFilters,
  onResetFilters,
  totalResults,
}) => {
  const isFiltered =
    filters.category !== 'All' ||
    filters.brand !== 'All' ||
    filters.search !== '' ||
    filters.maxPrice < 300 ||
    filters.selectedSize !== null;

  return (
    <div className="w-full space-y-4 mb-6">
      {/* Categories Horizontal Scroll */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none no-scrollbar">
        {CATEGORIES.map((category) => {
          const isActive = filters.category === category;
          return (
            <button
              key={category}
              onClick={() => onChangeFilters({ category: category as ShoeCategory })}
              className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-bold whitespace-nowrap transition-all duration-200 cursor-pointer ${
                isActive
                  ? 'bg-red-600 text-white shadow-md shadow-red-500/30 ring-2 ring-red-600'
                  : 'bg-white text-neutral-700 hover:bg-neutral-100 border border-neutral-200'
              }`}
            >
              {category}
            </button>
          );
        })}
      </div>

      {/* Brand & Filter Controls Bar */}
      <div className="bg-white p-3.5 sm:p-4 rounded-2xl border border-neutral-200/80 shadow-sm flex flex-col md:flex-row md:items-center justify-between gap-3">
        {/* Brand Chips */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 md:pb-0 scrollbar-none">
          <span className="text-xs font-bold text-neutral-400 uppercase tracking-wider mr-1 hidden sm:inline">
            Brand:
          </span>
          {BRANDS.map((brand) => {
            const isSelected = filters.brand === brand;
            return (
              <button
                key={brand}
                onClick={() => onChangeFilters({ brand: isSelected && brand !== 'All' ? 'All' : brand })}
                className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer ${
                  isSelected
                    ? 'bg-neutral-900 text-white shadow-sm'
                    : 'bg-neutral-100 text-neutral-600 hover:bg-neutral-200'
                }`}
              >
                {brand}
              </button>
            );
          })}
        </div>

        {/* Right Sort & Count */}
        <div className="flex items-center justify-between md:justify-end gap-3 pt-2 md:pt-0 border-t md:border-t-0 border-neutral-100">
          <span className="text-xs font-medium text-neutral-500">
            Showing <strong className="text-neutral-900 font-bold">{totalResults}</strong> shoes
          </span>

          <div className="flex items-center gap-2">
            {/* Sort Select */}
            <select
              value={filters.sort}
              onChange={(e) => onChangeFilters({ sort: e.target.value as any })}
              className="bg-neutral-50 border border-neutral-300 text-neutral-800 text-xs font-semibold rounded-lg px-2.5 py-1.5 focus:outline-none focus:ring-2 focus:ring-red-500 cursor-pointer"
              aria-label="Sort footwear"
            >
              <option value="featured">Featured Drops</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
              <option value="rating">Highest Rated</option>
              <option value="newest">Newest Arrivals</option>
            </select>

            {/* Clear Filters Button if any active */}
            {isFiltered && (
              <button
                onClick={onResetFilters}
                className="p-1.5 text-neutral-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors cursor-pointer"
                title="Reset filters"
                aria-label="Reset all filters"
              >
                <RotateCcw className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>

      {/* Quick Size Filter Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 text-xs text-neutral-600">
        <span className="font-semibold text-neutral-400 whitespace-nowrap text-xs">US Size:</span>
        <button
          onClick={() => onChangeFilters({ selectedSize: null })}
          className={`px-2.5 py-1 rounded-md font-bold transition-colors cursor-pointer ${
            filters.selectedSize === null
              ? 'bg-red-600 text-white'
              : 'bg-white border border-neutral-200 text-neutral-600 hover:bg-neutral-50'
          }`}
        >
          All
        </button>
        {COMMON_SIZES.map((size) => {
          const isSelected = filters.selectedSize === size;
          return (
            <button
              key={size}
              onClick={() => onChangeFilters({ selectedSize: isSelected ? null : size })}
              className={`px-2.5 py-1 rounded-md font-semibold transition-colors cursor-pointer ${
                isSelected
                  ? 'bg-neutral-900 text-white shadow-sm'
                  : 'bg-white border border-neutral-200 text-neutral-600 hover:bg-neutral-100'
              }`}
            >
              {size}
            </button>
          );
        })}
      </div>
    </div>
  );
};
