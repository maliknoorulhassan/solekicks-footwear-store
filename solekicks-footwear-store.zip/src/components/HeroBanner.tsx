import React from 'react';
import { ArrowRight, Flame, Shield, Zap, Sparkles } from 'lucide-react';

interface HeroBannerProps {
  onShopNow: () => void;
  onExploreBrand: (brand: string) => void;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({ onShopNow, onExploreBrand }) => {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-neutral-950 via-neutral-900 to-red-950 text-white rounded-3xl mx-4 sm:mx-6 lg:mx-8 my-4 sm:my-6 shadow-2xl border border-neutral-800">
      {/* Background glow & accents */}
      <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 bg-red-600/20 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute bottom-0 left-1/3 -mb-20 w-80 h-80 bg-rose-500/15 rounded-full blur-3xl pointer-events-none" />

      <div className="container mx-auto px-6 py-10 sm:py-14 lg:py-16 relative z-10">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
          {/* Left Text Content */}
          <div className="lg:col-span-7 space-y-5 text-left">
            <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-red-600/30 border border-red-500/40 text-rose-300 text-xs font-bold tracking-wider uppercase">
              <Flame className="w-4 h-4 text-amber-400" />
              <span>Summer 2026 Sneaker Edition</span>
            </div>

            <h1 className="font-display text-3xl sm:text-4xl md:text-5xl lg:text-6xl font-extrabold tracking-tight leading-[1.08] text-white">
              STEP INTO <span className="text-transparent bg-clip-text bg-gradient-to-r from-red-500 via-rose-400 to-amber-300">GREATNESS.</span>
            </h1>

            <p className="text-sm sm:text-base text-neutral-300 max-w-xl font-normal leading-relaxed">
              Curated rare retros, performance running silhouettes, and street classics with verified authenticity and 2-day delivery guarantee.
            </p>

            {/* CTAs */}
            <div className="flex flex-wrap items-center gap-3 pt-2">
              <button
                onClick={onShopNow}
                className="px-6 py-3.5 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-bold text-sm sm:text-base shadow-lg shadow-red-600/40 hover:scale-105 active:scale-95 transition-all flex items-center gap-2 cursor-pointer"
              >
                <span>Shop All Kicks</span>
                <ArrowRight className="w-4 h-4 stroke-[2.5]" />
              </button>
              <button
                onClick={() => onExploreBrand('Jordan')}
                className="px-5 py-3.5 rounded-xl bg-white/10 hover:bg-white/20 text-white font-semibold text-sm sm:text-base backdrop-blur-sm border border-white/15 transition-all cursor-pointer flex items-center gap-2"
              >
                <Sparkles className="w-4 h-4 text-amber-400" />
                <span>Jordan Retro Vault</span>
              </button>
            </div>

            {/* Quick feature pills */}
            <div className="grid grid-cols-3 gap-2 sm:gap-4 pt-4 border-t border-white/10 text-xs sm:text-sm">
              <div className="flex items-center gap-2 text-neutral-300">
                <Shield className="w-4 h-4 text-red-400 shrink-0" />
                <span>100% Genuine</span>
              </div>
              <div className="flex items-center gap-2 text-neutral-300">
                <Zap className="w-4 h-4 text-amber-400 shrink-0" />
                <span>Instant Dispatch</span>
              </div>
              <div className="flex items-center gap-2 text-neutral-300">
                <span className="w-2 h-2 rounded-full bg-emerald-400 shrink-0 animate-ping" />
                <span>Free 30-Day Returns</span>
              </div>
            </div>
          </div>

          {/* Right Hero Image Card */}
          <div className="lg:col-span-5 flex justify-center relative">
            <div className="relative w-full max-w-md aspect-[4/3] rounded-2xl overflow-hidden bg-neutral-800/80 border border-neutral-700/60 shadow-2xl group">
              <img
                src="https://images.unsplash.com/photo-1552346154-21d32810aba3?auto=format&fit=crop&w=1000&q=85"
                alt="Air Jordan 1 Retro High Chicago Edition"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                loading="eager"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent flex flex-col justify-end p-5">
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-[11px] font-bold text-red-400 uppercase tracking-wider">Top Featured Drop</span>
                    <h2 className="font-display text-lg sm:text-xl font-bold text-white">AJ1 Retro "Chicago"</h2>
                  </div>
                  <div className="text-right">
                    <span className="text-xs text-neutral-400 line-through mr-1.5">$220</span>
                    <span className="text-base sm:text-lg font-black text-amber-300">$195</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
