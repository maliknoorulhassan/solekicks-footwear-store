import React, { useState } from 'react';
import { Product } from '../types';
import {
  X,
  Star,
  Heart,
  ShoppingBag,
  Truck,
  ShieldCheck,
  RotateCcw,
  Check,
  Zap,
} from 'lucide-react';
import { formatCurrency } from '../utils/cart';

interface ProductDetailModalProps {
  product: Product | null;
  isOpen: boolean;
  onClose: () => void;
  isWishlisted: boolean;
  onToggleWishlist: (product: Product) => void;
  onAddToCart: (product: Product, size: number, color: string, quantity: number) => void;
  onBuyNow: (product: Product, size: number, color: string, quantity: number) => void;
}

export const ProductDetailModal: React.FC<ProductDetailModalProps> = ({
  product,
  isOpen,
  onClose,
  isWishlisted,
  onToggleWishlist,
  onAddToCart,
  onBuyNow,
}) => {
  if (!isOpen || !product) return null;

  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [selectedColorIndex, setSelectedColorIndex] = useState(0);
  const [selectedSize, setSelectedSize] = useState<number>(product.sizes[0] || 9);
  const [quantity, setQuantity] = useState(1);
  const [addedToast, setAddedToast] = useState(false);

  const images = product.gallery && product.gallery.length > 0 ? product.gallery : [product.heroImage];
  const discountPercent = product.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  const handleAdd = () => {
    onAddToCart(product, selectedSize, product.colors[selectedColorIndex].name, quantity);
    setAddedToast(true);
    setTimeout(() => setAddedToast(false), 2000);
  };

  const handleInstantBuy = () => {
    onBuyNow(product, selectedSize, product.colors[selectedColorIndex].name, quantity);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="product-modal-title"
      className="fixed inset-0 z-50 overflow-y-auto bg-neutral-950/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 md:p-6 animate-in fade-in duration-200"
    >
      <div
        className="relative w-full max-w-4xl bg-white rounded-3xl shadow-2xl overflow-hidden border border-neutral-200 my-auto max-h-[92vh] flex flex-col md:flex-row"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-20 w-10 h-10 rounded-full bg-white/80 hover:bg-neutral-100 backdrop-blur-md text-neutral-800 flex items-center justify-center shadow-md transition-colors cursor-pointer"
          aria-label="Close details"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Left: Enhanced Image Gallery */}
        <div className="w-full md:w-1/2 bg-neutral-100 p-4 sm:p-6 flex flex-col justify-between">
          {/* Main Large Display Image */}
          <div className="relative aspect-square w-full rounded-2xl overflow-hidden bg-white shadow-inner flex items-center justify-center group">
            <img
              src={images[activeImageIndex] || product.heroImage}
              alt={product.name}
              className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-300"
            />
            {discountPercent > 0 && (
              <span className="absolute top-3 left-3 bg-red-600 text-white font-extrabold text-xs px-2.5 py-1 rounded-lg shadow-sm">
                SAVE {discountPercent}%
              </span>
            )}
          </div>

          {/* Thumbnails */}
          <div className="flex items-center gap-2 mt-4 overflow-x-auto pb-1">
            {images.map((img, idx) => (
              <button
                key={idx}
                onClick={() => setActiveImageIndex(idx)}
                className={`relative w-16 h-16 rounded-xl overflow-hidden bg-white border-2 transition-all cursor-pointer shrink-0 ${
                  activeImageIndex === idx ? 'border-red-600 ring-2 ring-red-500/30' : 'border-neutral-200 opacity-70 hover:opacity-100'
                }`}
              >
                <img src={img} alt={`View angle ${idx + 1}`} className="w-full h-full object-cover" />
              </button>
            ))}
          </div>
        </div>

        {/* Right: Product Details, Options, & Actions */}
        <div className="w-full md:w-1/2 p-5 sm:p-8 flex flex-col justify-between overflow-y-auto max-h-[60vh] md:max-h-[92vh]">
          <div className="space-y-4">
            {/* Brand, Title & Rating */}
            <div>
              <div className="flex items-center justify-between text-xs font-bold text-neutral-400 uppercase tracking-widest">
                <span>{product.brand}</span>
                <span className="text-emerald-600">● {product.inStock} In Stock</span>
              </div>
              <h2 id="product-modal-title" className="font-display text-xl sm:text-2xl font-black text-neutral-900 mt-1">
                {product.name}
              </h2>
              <div className="flex items-center gap-3 mt-2">
                <div className="flex items-center gap-1 text-amber-500 font-bold text-sm">
                  <Star className="w-4 h-4 fill-amber-400 text-amber-400" />
                  <span>{product.rating.toFixed(1)}</span>
                </div>
                <span className="text-neutral-300">|</span>
                <span className="text-neutral-500 text-xs font-medium underline">
                  {product.reviewCount} Verified Sneakerhead Reviews
                </span>
              </div>
            </div>

            {/* Price section */}
            <div className="flex items-baseline gap-3 py-2 border-y border-neutral-100">
              <span className="font-display font-extrabold text-2xl sm:text-3xl text-neutral-900">
                {formatCurrency(product.price)}
              </span>
              {product.originalPrice && (
                <span className="text-base text-neutral-400 line-through">
                  {formatCurrency(product.originalPrice)}
                </span>
              )}
              <span className="text-xs font-bold text-red-600 bg-red-50 px-2 py-0.5 rounded">
                Eligible for code KICKS20
              </span>
            </div>

            {/* Colorway Selection */}
            <div>
              <label className="text-xs font-bold uppercase tracking-wider text-neutral-600 block mb-2">
                Colorway: <span className="text-neutral-900 font-extrabold">{product.colors[selectedColorIndex].name}</span>
              </label>
              <div className="flex items-center gap-2">
                {product.colors.map((c, idx) => (
                  <button
                    key={c.name}
                    onClick={() => setSelectedColorIndex(idx)}
                    className={`w-8 h-8 rounded-full border-2 transition-all cursor-pointer flex items-center justify-center ${
                      selectedColorIndex === idx ? 'border-red-600 ring-2 ring-red-400/50 scale-110' : 'border-neutral-200'
                    }`}
                    style={{ backgroundColor: c.hex }}
                    aria-label={`Color ${c.name}`}
                  >
                    {selectedColorIndex === idx && (
                      <Check className={`w-4 h-4 ${c.hex === '#FFFFFF' || c.hex === '#F3F4F6' ? 'text-black' : 'text-white'}`} />
                    )}
                  </button>
                ))}
              </div>
            </div>

            {/* Size Selector */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <label className="text-xs font-bold uppercase tracking-wider text-neutral-600">
                  Select Size (US Men)
                </label>
                <span className="text-xs text-red-600 font-semibold underline cursor-pointer">
                  Size Guide
                </span>
              </div>
              <div className="grid grid-cols-4 sm:grid-cols-5 gap-2">
                {product.sizes.map((size) => {
                  const isSelected = selectedSize === size;
                  return (
                    <button
                      key={size}
                      onClick={() => setSelectedSize(size)}
                      className={`py-2 rounded-xl text-xs font-bold transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-neutral-900 text-white shadow-md'
                          : 'bg-neutral-100 hover:bg-neutral-200 text-neutral-700 border border-neutral-200'
                      }`}
                    >
                      US {size}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Quantity Selector */}
            <div className="flex items-center gap-3">
              <span className="text-xs font-bold uppercase tracking-wider text-neutral-600">Quantity</span>
              <div className="flex items-center border border-neutral-200 rounded-xl bg-neutral-50 p-1">
                <button
                  onClick={() => setQuantity(Math.max(1, quantity - 1))}
                  className="w-7 h-7 rounded-lg bg-white hover:bg-neutral-100 text-neutral-800 font-bold flex items-center justify-center shadow-xs disabled:opacity-50"
                  disabled={quantity <= 1}
                  aria-label="Decrease quantity"
                >
                  -
                </button>
                <span className="w-10 text-center font-bold text-sm text-neutral-900">{quantity}</span>
                <button
                  onClick={() => setQuantity(Math.min(product.inStock, quantity + 1))}
                  className="w-7 h-7 rounded-lg bg-white hover:bg-neutral-100 text-neutral-800 font-bold flex items-center justify-center shadow-xs"
                  aria-label="Increase quantity"
                >
                  +
                </button>
              </div>
            </div>

            {/* Specs & Description */}
            <div className="pt-2 text-xs text-neutral-600 space-y-2">
              <p className="leading-relaxed">{product.description}</p>
              <div className="bg-neutral-50 rounded-xl p-3 grid grid-cols-2 gap-2 text-[11px]">
                <div>
                  <span className="text-neutral-400 block font-medium">Cushioning</span>
                  <span className="font-bold text-neutral-800">{product.specs.cushioning}</span>
                </div>
                <div>
                  <span className="text-neutral-400 block font-medium">Upper</span>
                  <span className="font-bold text-neutral-800">{product.specs.upperMaterial}</span>
                </div>
                <div>
                  <span className="text-neutral-400 block font-medium">Weight</span>
                  <span className="font-bold text-neutral-800">{product.specs.weight}</span>
                </div>
                <div>
                  <span className="text-neutral-400 block font-medium">Closure</span>
                  <span className="font-bold text-neutral-800">{product.specs.closure}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Action Buttons & Guarantees */}
          <div className="pt-4 mt-4 border-t border-neutral-100 space-y-2">
            <div className="flex items-center gap-2">
              {/* Add to Cart Button */}
              <button
                onClick={handleAdd}
                className="flex-1 py-3.5 px-4 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white font-bold text-sm shadow-md flex items-center justify-center gap-2 active:scale-98 transition-all cursor-pointer"
                aria-label={`Add ${product.name} to shopping bag`}
              >
                {addedToast ? (
                  <>
                    <Check className="w-4 h-4 stroke-[3] text-emerald-400" />
                    <span>Added to Cart!</span>
                  </>
                ) : (
                  <>
                    <ShoppingBag className="w-4 h-4" />
                    <span>Add to Bag</span>
                  </>
                )}
              </button>

              {/* Instant Buy Now Button */}
              <button
                onClick={handleInstantBuy}
                className="flex-1 py-3.5 px-4 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-bold text-sm shadow-md flex items-center justify-center gap-2 active:scale-98 transition-all cursor-pointer"
                aria-label={`Buy ${product.name} instantly`}
              >
                <Zap className="w-4 h-4 fill-amber-300 text-amber-300" />
                <span>Buy Now</span>
              </button>

              {/* Wishlist Button */}
              <button
                onClick={() => onToggleWishlist(product)}
                className={`p-3.5 rounded-xl border transition-all cursor-pointer ${
                  isWishlisted
                    ? 'border-red-300 bg-red-50 text-red-600'
                    : 'border-neutral-200 bg-white hover:bg-neutral-50 text-neutral-600'
                }`}
                aria-label={isWishlisted ? 'Remove from wishlist' : 'Save to wishlist'}
              >
                <Heart className={`w-5 h-5 ${isWishlisted ? 'fill-red-600' : ''}`} />
              </button>
            </div>

            {/* Assurance trust line */}
            <div className="flex items-center justify-between text-[11px] text-neutral-400 pt-1 px-1">
              <span className="flex items-center gap-1">
                <Truck className="w-3.5 h-3.5 text-emerald-500" /> Fast delivery
              </span>
              <span className="flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5 text-blue-500" /> Authenticity guaranteed
              </span>
              <span className="flex items-center gap-1">
                <RotateCcw className="w-3.5 h-3.5 text-neutral-500" /> Free returns
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
