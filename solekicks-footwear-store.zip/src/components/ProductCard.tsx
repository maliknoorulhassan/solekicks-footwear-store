import React, { useState } from 'react';
import { Product } from '../types';
import { Star, Heart, ShoppingBag, Eye, Check } from 'lucide-react';
import { formatCurrency } from '../utils/cart';

interface ProductCardProps {
  product: Product;
  isWishlisted: boolean;
  onToggleWishlist: (product: Product) => void;
  onSelectProduct: (product: Product) => void;
  onQuickAddToCart: (product: Product, size: number, color: string) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  isWishlisted,
  onToggleWishlist,
  onSelectProduct,
  onQuickAddToCart,
}) => {
  const [selectedColorIndex, setSelectedColorIndex] = useState(0);
  const [showQuickSizes, setShowQuickSizes] = useState(false);
  const [justAdded, setJustAdded] = useState(false);

  const discountPercent = product.originalPrice
    ? Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)
    : 0;

  const handleQuickAdd = (size: number, e: React.MouseEvent) => {
    e.stopPropagation();
    onQuickAddToCart(product, size, product.colors[selectedColorIndex].name);
    setShowQuickSizes(false);
    setJustAdded(true);
    setTimeout(() => setJustAdded(false), 1500);
  };

  return (
    <article
      onClick={() => onSelectProduct(product)}
      className="group relative bg-white rounded-2xl border border-neutral-200/90 overflow-hidden shadow-sm hover:shadow-xl transition-all duration-300 flex flex-col cursor-pointer"
    >
      {/* Top Image Box */}
      <div className="relative aspect-[4/3] bg-neutral-100 overflow-hidden flex items-center justify-center p-3">
        {/* Badges */}
        <div className="absolute top-2.5 left-2.5 z-10 flex flex-col gap-1 items-start">
          {product.isNew && (
            <span className="px-2 py-0.5 rounded-md bg-neutral-900 text-white text-[10px] font-extrabold uppercase tracking-wider">
              NEW
            </span>
          )}
          {discountPercent > 0 && (
            <span className="px-2 py-0.5 rounded-md bg-red-600 text-white text-[10px] font-extrabold tracking-wider">
              -{discountPercent}%
            </span>
          )}
          {product.isTrending && (
            <span className="px-2 py-0.5 rounded-md bg-amber-400 text-neutral-950 text-[10px] font-black uppercase tracking-wider">
              HOT
            </span>
          )}
        </div>

        {/* Favorite Heart Button */}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onToggleWishlist(product);
          }}
          className={`absolute top-2.5 right-2.5 z-10 w-8 h-8 rounded-full flex items-center justify-center transition-all ${
            isWishlisted
              ? 'bg-rose-50 text-red-600 shadow-md ring-1 ring-red-200'
              : 'bg-white/80 backdrop-blur-sm text-neutral-500 hover:text-red-600 hover:bg-white shadow-sm'
          }`}
          aria-label={isWishlisted ? `Remove ${product.name} from wishlist` : `Add ${product.name} to wishlist`}
        >
          <Heart className={`w-4 h-4 ${isWishlisted ? 'fill-red-600' : ''}`} />
        </button>

        {/* High-Res Product Image */}
        <img
          src={product.heroImage}
          alt={product.name}
          className="w-full h-full object-cover object-center group-hover:scale-108 transition-transform duration-500 rounded-xl"
          loading="lazy"
        />

        {/* Quick Sizes Popover Overlay */}
        {showQuickSizes && (
          <div
            onClick={(e) => e.stopPropagation()}
            className="absolute inset-0 bg-neutral-950/85 backdrop-blur-sm z-20 p-3 flex flex-col justify-between text-white animate-in fade-in duration-200"
          >
            <div className="flex items-center justify-between text-xs pb-1 border-b border-white/20">
              <span className="font-bold text-amber-300">Select US Size</span>
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  setShowQuickSizes(false);
                }}
                className="text-neutral-300 hover:text-white font-bold text-xs"
              >
                ✕
              </button>
            </div>
            <div className="grid grid-cols-4 gap-1.5 my-auto max-h-36 overflow-y-auto py-1">
              {product.sizes.map((size) => (
                <button
                  key={size}
                  onClick={(e) => handleQuickAdd(size, e)}
                  className="py-1.5 rounded-lg bg-white/10 hover:bg-red-600 text-xs font-bold text-white transition-colors border border-white/10 active:scale-95"
                >
                  {size}
                </button>
              ))}
            </div>
            <p className="text-[10px] text-center text-neutral-400">Tap size to add instantly</p>
          </div>
        )}
      </div>

      {/* Card Body */}
      <div className="p-3.5 sm:p-4 flex-1 flex flex-col justify-between space-y-2">
        <div>
          {/* Brand & Rating */}
          <div className="flex items-center justify-between text-xs text-neutral-500 mb-1">
            <span className="font-bold uppercase tracking-wider text-neutral-400 text-[11px]">
              {product.brand}
            </span>
            <div className="flex items-center gap-1 text-amber-500 font-bold">
              <Star className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
              <span>{product.rating.toFixed(1)}</span>
              <span className="text-neutral-400 text-[10px]">({product.reviewCount})</span>
            </div>
          </div>

          {/* Product Title */}
          <h3 className="font-display font-bold text-sm sm:text-base text-neutral-900 line-clamp-1 group-hover:text-red-600 transition-colors">
            {product.name}
          </h3>

          {/* Colorway preview circles */}
          <div className="flex items-center gap-1.5 mt-2">
            {product.colors.map((color, idx) => (
              <button
                key={color.name}
                onClick={(e) => {
                  e.stopPropagation();
                  setSelectedColorIndex(idx);
                }}
                className={`w-3.5 h-3.5 rounded-full border transition-all ${
                  selectedColorIndex === idx
                    ? 'ring-2 ring-red-500 ring-offset-1 scale-110'
                    : 'border-neutral-300'
                }`}
                style={{ backgroundColor: color.hex }}
                title={color.name}
                aria-label={`Select ${color.name}`}
              />
            ))}
            <span className="text-[10px] text-neutral-400 ml-1">
              {product.colors[selectedColorIndex].name}
            </span>
          </div>
        </div>

        {/* Price & Action Buttons */}
        <div className="pt-2 border-t border-neutral-100 flex items-center justify-between gap-2">
          <div className="flex flex-col">
            <div className="flex items-baseline gap-1.5">
              <span className="font-display font-extrabold text-base sm:text-lg text-neutral-900">
                {formatCurrency(product.price)}
              </span>
              {product.originalPrice && (
                <span className="text-xs text-neutral-400 line-through">
                  {formatCurrency(product.originalPrice)}
                </span>
              )}
            </div>
            <span className="text-[10px] font-semibold text-emerald-600">
              {product.inStock < 10 ? `Only ${product.inStock} left!` : 'In Stock'}
            </span>
          </div>

          {/* Quick Add Button */}
          <button
            onClick={(e) => {
              e.stopPropagation();
              setShowQuickSizes(!showQuickSizes);
            }}
            className={`px-3 py-2 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 cursor-pointer ${
              justAdded
                ? 'bg-emerald-600 text-white'
                : 'bg-neutral-900 hover:bg-red-600 text-white active:scale-95 shadow-sm'
            }`}
            aria-label={`Add ${product.name} to bag`}
          >
            {justAdded ? (
              <>
                <Check className="w-3.5 h-3.5 stroke-[3]" />
                <span className="hidden sm:inline">Added</span>
              </>
            ) : (
              <>
                <ShoppingBag className="w-3.5 h-3.5" />
                <span>+ Bag</span>
              </>
            )}
          </button>
        </div>
      </div>
    </article>
  );
};
