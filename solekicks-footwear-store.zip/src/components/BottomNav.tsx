import React from 'react';
import { Home, Sparkles, Heart, ShoppingBag, Package } from 'lucide-react';
import { formatCurrency } from '../utils/cart';

interface BottomNavProps {
  cartCount: number;
  cartTotal: number;
  wishlistCount: number;
  activeTab: 'home' | 'catalog' | 'wishlist' | 'cart' | 'orders';
  onNavigateHome: () => void;
  onNavigateCatalog: () => void;
  onOpenWishlist: () => void;
  onOpenCart: () => void;
  onOpenOrders: () => void;
}

export const BottomNav: React.FC<BottomNavProps> = ({
  cartCount,
  cartTotal,
  wishlistCount,
  activeTab,
  onNavigateHome,
  onNavigateCatalog,
  onOpenWishlist,
  onOpenCart,
  onOpenOrders,
}) => {
  return (
    <nav
      className="md:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/95 backdrop-blur-md border-t border-neutral-200 shadow-2xl px-2 py-1.5 safe-bottom"
      aria-label="Mobile bottom navigation"
    >
      <div className="grid grid-cols-5 items-center justify-around max-w-md mx-auto">
        {/* Home */}
        <button
          onClick={onNavigateHome}
          className={`flex flex-col items-center justify-center py-1 rounded-xl transition-all ${
            activeTab === 'home' ? 'text-red-600 font-bold' : 'text-neutral-500 hover:text-neutral-900'
          }`}
          aria-label="Navigate to Home"
        >
          <Home className="w-5 h-5 mb-0.5" />
          <span className="text-[10px]">Home</span>
        </button>

        {/* Shop / Explore */}
        <button
          onClick={onNavigateCatalog}
          className={`flex flex-col items-center justify-center py-1 rounded-xl transition-all ${
            activeTab === 'catalog' ? 'text-red-600 font-bold' : 'text-neutral-500 hover:text-neutral-900'
          }`}
          aria-label="Navigate to Catalog"
        >
          <Sparkles className="w-5 h-5 mb-0.5" />
          <span className="text-[10px]">Shop</span>
        </button>

        {/* Wishlist */}
        <button
          onClick={onOpenWishlist}
          className={`relative flex flex-col items-center justify-center py-1 rounded-xl transition-all ${
            activeTab === 'wishlist' ? 'text-red-600 font-bold' : 'text-neutral-500 hover:text-neutral-900'
          }`}
          aria-label={`Open Wishlist (${wishlistCount} items)`}
        >
          <div className="relative">
            <Heart className={`w-5 h-5 mb-0.5 ${wishlistCount > 0 ? 'text-amber-500 fill-amber-500' : ''}`} />
            {wishlistCount > 0 && (
              <span className="absolute -top-1 -right-2 bg-amber-400 text-neutral-950 text-[9px] font-black w-4 h-4 rounded-full flex items-center justify-center">
                {wishlistCount}
              </span>
            )}
          </div>
          <span className="text-[10px]">Saved</span>
        </button>

        {/* Prominent Cart Button for Quick Access */}
        <button
          onClick={onOpenCart}
          className="relative flex flex-col items-center justify-center py-1 rounded-xl group transition-all"
          aria-label={`Open shopping cart with ${cartCount} items, total ${formatCurrency(cartTotal)}`}
        >
          <div className="relative p-1.5 -mt-3 rounded-full bg-gradient-to-r from-red-600 to-rose-600 text-white shadow-lg shadow-red-500/30 group-active:scale-95 transition-transform">
            <ShoppingBag className="w-5 h-5" />
            {cartCount > 0 && (
              <span className="absolute -top-1 -right-1 bg-amber-300 text-neutral-950 text-[10px] font-black min-w-4.5 h-4.5 px-0.5 rounded-full flex items-center justify-center border border-white">
                {cartCount}
              </span>
            )}
          </div>
          <span className="text-[10px] font-bold text-red-600 mt-0.5">
            {cartCount > 0 ? formatCurrency(cartTotal) : 'Cart'}
          </span>
        </button>

        {/* Orders Tracking */}
        <button
          onClick={onOpenOrders}
          className={`flex flex-col items-center justify-center py-1 rounded-xl transition-all ${
            activeTab === 'orders' ? 'text-red-600 font-bold' : 'text-neutral-500 hover:text-neutral-900'
          }`}
          aria-label="View My Orders"
        >
          <Package className="w-5 h-5 mb-0.5" />
          <span className="text-[10px]">Orders</span>
        </button>
      </div>
    </nav>
  );
};
