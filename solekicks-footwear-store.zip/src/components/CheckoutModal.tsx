import React, { useState } from 'react';
import { CartItem, CartTotals, Order, ShippingAddress } from '../types';
import {
  X,
  CreditCard,
  Truck,
  ShieldCheck,
  CheckCircle2,
  Lock,
  ArrowRight,
  Package,
} from 'lucide-react';
import { formatCurrency } from '../utils/cart';

interface CheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  totals: CartTotals;
  onOrderPlaced: (order: Order) => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  isOpen,
  onClose,
  items,
  totals,
  onOrderPlaced,
}) => {
  if (!isOpen) return null;

  const [step, setStep] = useState<'shipping' | 'payment' | 'confirmed'>('shipping');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [createdOrder, setCreatedOrder] = useState<Order | null>(null);

  // Shipping Form State
  const [shipping, setShipping] = useState<ShippingAddress>({
    fullName: 'Alex Morgan',
    email: 'alex.morgan@example.com',
    phone: '(555) 382-9102',
    street: '742 Evergreen Terrace',
    city: 'Springfield',
    postalCode: '97477',
    country: 'United States',
  });

  const [shippingErrors, setShippingErrors] = useState<Record<string, string>>({});

  // Payment Form State
  const [paymentMethod, setPaymentMethod] = useState<'card' | 'applepay' | 'cod'>('card');
  const [cardNumber, setCardNumber] = useState('4242 •••• •••• 4242');
  const [cardExpiry, setCardExpiry] = useState('12/28');
  const [cardCvc, setCardCvc] = useState('888');

  const validateShipping = () => {
    const errors: Record<string, string> = {};
    if (!shipping.fullName.trim()) errors.fullName = 'Full name is required';
    if (!shipping.email.trim() || !shipping.email.includes('@')) errors.email = 'Valid email is required';
    if (!shipping.phone.trim()) errors.phone = 'Phone number is required';
    if (!shipping.street.trim()) errors.street = 'Street address is required';
    if (!shipping.city.trim()) errors.city = 'City is required';
    if (!shipping.postalCode.trim()) errors.postalCode = 'Postal code is required';

    setShippingErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleProceedToPayment = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateShipping()) {
      setStep('payment');
    }
  };

  const handlePlaceOrder = () => {
    setIsSubmitting(true);
    setTimeout(() => {
      const orderId = `SK-${Math.floor(100000 + Math.random() * 900000)}`;
      const trackingNumber = `TRK-US-${Math.floor(10000000 + Math.random() * 90000000)}`;
      const newOrder: Order = {
        id: orderId,
        createdAt: new Date().toLocaleDateString('en-US', {
          month: 'short',
          day: 'numeric',
          year: 'numeric',
          hour: '2-digit',
          minute: '2-digit',
        }),
        items: [...items],
        totals: { ...totals },
        shippingAddress: { ...shipping },
        paymentMethod,
        status: 'Confirmed',
        trackingNumber,
        estimatedDelivery: '3 - 5 Business Days (Standard Express)',
      };

      setCreatedOrder(newOrder);
      setIsSubmitting(false);
      setStep('confirmed');
      onOrderPlaced(newOrder);
    }, 1000);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="checkout-modal-title"
      className="fixed inset-0 z-50 overflow-y-auto bg-neutral-950/70 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 md:p-6 animate-in fade-in duration-200"
    >
      <div
        className="relative w-full max-w-2xl bg-white rounded-3xl shadow-2xl overflow-hidden border border-neutral-200 my-auto flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-neutral-200 flex items-center justify-between bg-neutral-50">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-red-600 text-white flex items-center justify-center shadow-xs">
              <Lock className="w-4 h-4" />
            </div>
            <div>
              <h2 id="checkout-modal-title" className="font-display font-extrabold text-lg text-neutral-900">
                {step === 'confirmed' ? 'Order Confirmed!' : 'Express Secure Checkout'}
              </h2>
              <p className="text-xs text-neutral-500">
                {step === 'shipping' && 'Step 1 of 2: Delivery Details'}
                {step === 'payment' && 'Step 2 of 2: Payment Method'}
                {step === 'confirmed' && 'Thank you for your purchase'}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-neutral-400 hover:text-neutral-700 hover:bg-neutral-200 rounded-full transition-colors cursor-pointer"
            aria-label="Close checkout"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="p-5 sm:p-6 overflow-y-auto max-h-[75vh]">
          {step === 'shipping' && (
            <form onSubmit={handleProceedToPayment} className="space-y-4">
              <div className="bg-red-50/70 border border-red-200/80 rounded-xl p-3 flex items-center justify-between text-xs">
                <span className="font-semibold text-neutral-700">
                  Cart Total ({totals.itemsCount} {totals.itemsCount === 1 ? 'item' : 'items'}):
                </span>
                <span className="font-display font-black text-sm text-red-600">
                  {formatCurrency(totals.total)}
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                <div>
                  <label className="block text-xs font-bold text-neutral-700 mb-1">
                    Full Name *
                  </label>
                  <input
                    type="text"
                    value={shipping.fullName}
                    onChange={(e) => setShipping({ ...shipping, fullName: e.target.value })}
                    className={`w-full text-xs font-medium bg-neutral-50 border rounded-xl px-3 py-2.5 focus:outline-none focus:ring-2 ${
                      shippingErrors.fullName ? 'border-red-500 focus:ring-red-400' : 'border-neutral-300 focus:ring-red-500'
                    }`}
                    placeholder="e.g. John Doe"
                  />
                  {shippingErrors.fullName && (
                    <p className="text-[10px] text-red-600 mt-1 font-semibold">{shippingErrors.fullName}</p>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-700 mb-1">
                    Email Address *
                  </label>
                  <input
                    type="email"
                    value={shipping.email}
                    onChange={(e) => setShipping({ ...shipping, email: e.target.value })}
                    className={`w-full text-xs font-medium bg-neutral-50 border rounded-xl px-3 py-2.5 focus:outline-none focus:ring-2 ${
                      shippingErrors.email ? 'border-red-500 focus:ring-red-400' : 'border-neutral-300 focus:ring-red-500'
                    }`}
                    placeholder="john@example.com"
                  />
                  {shippingErrors.email && (
                    <p className="text-[10px] text-red-600 mt-1 font-semibold">{shippingErrors.email}</p>
                  )}
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-neutral-700 mb-1">
                    Street Address *
                  </label>
                  <input
                    type="text"
                    value={shipping.street}
                    onChange={(e) => setShipping({ ...shipping, street: e.target.value })}
                    className={`w-full text-xs font-medium bg-neutral-50 border rounded-xl px-3 py-2.5 focus:outline-none focus:ring-2 ${
                      shippingErrors.street ? 'border-red-500 focus:ring-red-400' : 'border-neutral-300 focus:ring-red-500'
                    }`}
                    placeholder="Street and house number"
                  />
                  {shippingErrors.street && (
                    <p className="text-[10px] text-red-600 mt-1 font-semibold">{shippingErrors.street}</p>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-700 mb-1">
                    City *
                  </label>
                  <input
                    type="text"
                    value={shipping.city}
                    onChange={(e) => setShipping({ ...shipping, city: e.target.value })}
                    className={`w-full text-xs font-medium bg-neutral-50 border rounded-xl px-3 py-2.5 focus:outline-none focus:ring-2 ${
                      shippingErrors.city ? 'border-red-500 focus:ring-red-400' : 'border-neutral-300 focus:ring-red-500'
                    }`}
                    placeholder="City"
                  />
                  {shippingErrors.city && (
                    <p className="text-[10px] text-red-600 mt-1 font-semibold">{shippingErrors.city}</p>
                  )}
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-700 mb-1">
                    ZIP / Postal Code *
                  </label>
                  <input
                    type="text"
                    value={shipping.postalCode}
                    onChange={(e) => setShipping({ ...shipping, postalCode: e.target.value })}
                    className={`w-full text-xs font-medium bg-neutral-50 border rounded-xl px-3 py-2.5 focus:outline-none focus:ring-2 ${
                      shippingErrors.postalCode ? 'border-red-500 focus:ring-red-400' : 'border-neutral-300 focus:ring-red-500'
                    }`}
                    placeholder="10001"
                  />
                  {shippingErrors.postalCode && (
                    <p className="text-[10px] text-red-600 mt-1 font-semibold">{shippingErrors.postalCode}</p>
                  )}
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-xs font-bold text-neutral-700 mb-1">
                    Mobile Phone *
                  </label>
                  <input
                    type="tel"
                    value={shipping.phone}
                    onChange={(e) => setShipping({ ...shipping, phone: e.target.value })}
                    className={`w-full text-xs font-medium bg-neutral-50 border rounded-xl px-3 py-2.5 focus:outline-none focus:ring-2 ${
                      shippingErrors.phone ? 'border-red-500 focus:ring-red-400' : 'border-neutral-300 focus:ring-red-500'
                    }`}
                    placeholder="For delivery SMS updates"
                  />
                  {shippingErrors.phone && (
                    <p className="text-[10px] text-red-600 mt-1 font-semibold">{shippingErrors.phone}</p>
                  )}
                </div>
              </div>

              <button
                type="submit"
                className="w-full mt-4 py-3.5 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-bold text-sm shadow-md flex items-center justify-center gap-2 cursor-pointer transition-all"
              >
                <span>Continue to Payment</span>
                <ArrowRight className="w-4 h-4 stroke-[2.5]" />
              </button>
            </form>
          )}

          {step === 'payment' && (
            <div className="space-y-4">
              {/* Payment selector */}
              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setPaymentMethod('card')}
                  className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    paymentMethod === 'card'
                      ? 'border-red-600 bg-red-50/50 text-red-700 ring-2 ring-red-500/20'
                      : 'border-neutral-200 bg-white hover:bg-neutral-50 text-neutral-700'
                  }`}
                >
                  <CreditCard className="w-5 h-5 text-red-600" />
                  <span className="text-xs font-bold">Credit Card</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('applepay')}
                  className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    paymentMethod === 'applepay'
                      ? 'border-red-600 bg-red-50/50 text-red-700 ring-2 ring-red-500/20'
                      : 'border-neutral-200 bg-white hover:bg-neutral-50 text-neutral-700'
                  }`}
                >
                  <span className="text-sm font-black"> Pay</span>
                  <span className="text-xs font-bold">Apple / Google</span>
                </button>

                <button
                  type="button"
                  onClick={() => setPaymentMethod('cod')}
                  className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1.5 transition-all cursor-pointer ${
                    paymentMethod === 'cod'
                      ? 'border-red-600 bg-red-50/50 text-red-700 ring-2 ring-red-500/20'
                      : 'border-neutral-200 bg-white hover:bg-neutral-50 text-neutral-700'
                  }`}
                >
                  <Truck className="w-5 h-5 text-emerald-600" />
                  <span className="text-xs font-bold">Pay on Delivery</span>
                </button>
              </div>

              {/* Card inputs */}
              {paymentMethod === 'card' && (
                <div className="space-y-3 bg-neutral-50 p-4 rounded-2xl border border-neutral-200">
                  <div>
                    <label className="block text-xs font-bold text-neutral-700 mb-1">
                      Card Number
                    </label>
                    <input
                      type="text"
                      value={cardNumber}
                      onChange={(e) => setCardNumber(e.target.value)}
                      className="w-full text-xs font-mono bg-white border border-neutral-300 rounded-xl px-3 py-2.5 focus:ring-2 focus:ring-red-500"
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <label className="block text-xs font-bold text-neutral-700 mb-1">
                        Expiry Date
                      </label>
                      <input
                        type="text"
                        value={cardExpiry}
                        onChange={(e) => setCardExpiry(e.target.value)}
                        className="w-full text-xs font-mono bg-white border border-neutral-300 rounded-xl px-3 py-2.5 focus:ring-2 focus:ring-red-500"
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-bold text-neutral-700 mb-1">
                        CVC Security Code
                      </label>
                      <input
                        type="password"
                        value={cardCvc}
                        maxLength={4}
                        onChange={(e) => setCardCvc(e.target.value)}
                        className="w-full text-xs font-mono bg-white border border-neutral-300 rounded-xl px-3 py-2.5 focus:ring-2 focus:ring-red-500"
                      />
                    </div>
                  </div>
                </div>
              )}

              {paymentMethod === 'applepay' && (
                <div className="bg-neutral-900 text-white p-4 rounded-2xl text-center space-y-2">
                  <p className="text-xs text-neutral-300">
                    Instant biometric checkout will be processed securely with your device passkey.
                  </p>
                </div>
              )}

              {paymentMethod === 'cod' && (
                <div className="bg-emerald-50 text-emerald-900 p-4 rounded-2xl text-xs space-y-1 border border-emerald-200">
                  <p className="font-bold">Pay upon arrival</p>
                  <p className="text-neutral-600">
                    Pay in cash or card to the courier upon shoe delivery at {shipping.street}, {shipping.city}.
                  </p>
                </div>
              )}

              {/* Order Final Review */}
              <div className="bg-neutral-50 p-4 rounded-2xl border border-neutral-200 text-xs space-y-1.5">
                <div className="flex justify-between font-medium text-neutral-600">
                  <span>Shipping to:</span>
                  <span className="font-bold text-neutral-800">{shipping.fullName}</span>
                </div>
                <div className="flex justify-between font-medium text-neutral-600">
                  <span>Address:</span>
                  <span className="text-neutral-800">{shipping.street}, {shipping.city}</span>
                </div>
                <div className="flex justify-between font-extrabold text-sm text-neutral-900 pt-2 border-t border-neutral-200">
                  <span>Total Due:</span>
                  <span className="text-red-600 font-display text-base">{formatCurrency(totals.total)}</span>
                </div>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setStep('shipping')}
                  className="px-4 py-3 rounded-xl bg-neutral-100 hover:bg-neutral-200 text-neutral-700 font-bold text-xs transition-colors cursor-pointer"
                >
                  Back
                </button>
                <button
                  type="button"
                  onClick={handlePlaceOrder}
                  disabled={isSubmitting}
                  className="flex-1 py-3.5 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-extrabold text-sm shadow-lg shadow-red-600/30 flex items-center justify-center gap-2 transition-all cursor-pointer disabled:opacity-50"
                >
                  {isSubmitting ? (
                    <span>Authorizing Payment...</span>
                  ) : (
                    <>
                      <Lock className="w-4 h-4" />
                      <span>Place Footwear Order ({formatCurrency(totals.total)})</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          )}

          {step === 'confirmed' && createdOrder && (
            <div className="text-center py-4 space-y-5">
              <div className="w-16 h-16 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto shadow-inner animate-bounce">
                <CheckCircle2 className="w-10 h-10 stroke-[2.5]" />
              </div>

              <div>
                <h3 className="font-display font-extrabold text-2xl text-neutral-900">
                  You're all set! Order Placed!
                </h3>
                <p className="text-xs text-neutral-500 mt-1 max-w-sm mx-auto">
                  We've sent a detailed confirmation to <strong className="text-neutral-800">{createdOrder.shippingAddress.email}</strong>.
                </p>
              </div>

              {/* Order Info Card */}
              <div className="bg-neutral-50 rounded-2xl p-4 border border-neutral-200 text-left space-y-2 text-xs">
                <div className="flex justify-between pb-2 border-b border-neutral-200">
                  <span className="text-neutral-500 font-medium">Order Number:</span>
                  <span className="font-mono font-bold text-red-600">{createdOrder.id}</span>
                </div>
                <div className="flex justify-between pb-2 border-b border-neutral-200">
                  <span className="text-neutral-500 font-medium">Tracking Number:</span>
                  <span className="font-mono font-bold text-neutral-800">{createdOrder.trackingNumber}</span>
                </div>
                <div className="flex justify-between pb-2 border-b border-neutral-200">
                  <span className="text-neutral-500 font-medium">Estimated Arrival:</span>
                  <span className="font-semibold text-emerald-700">{createdOrder.estimatedDelivery}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-neutral-500 font-medium">Total Paid:</span>
                  <span className="font-extrabold text-neutral-900 text-sm">
                    {formatCurrency(createdOrder.totals.total)}
                  </span>
                </div>
              </div>

              {/* Purchased Shoes List */}
              <div className="text-left">
                <span className="text-xs font-bold text-neutral-400 uppercase tracking-wider block mb-2">
                  Items in this order:
                </span>
                <div className="space-y-2 max-h-36 overflow-y-auto">
                  {createdOrder.items.map((item) => (
                    <div
                      key={item.id}
                      className="flex items-center gap-3 p-2 rounded-xl bg-neutral-100/70 text-xs"
                    >
                      <img
                        src={item.product.heroImage}
                        alt={item.product.name}
                        className="w-10 h-10 rounded-lg object-cover bg-white"
                      />
                      <div className="flex-1 min-w-0">
                        <p className="font-bold text-neutral-800 truncate">{item.product.name}</p>
                        <p className="text-neutral-500 text-[11px]">
                          US {item.selectedSize} • {item.selectedColor} • Qty: {item.quantity}
                        </p>
                      </div>
                      <span className="font-bold text-neutral-900">
                        {formatCurrency(item.product.price * item.quantity)}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

              <button
                type="button"
                onClick={onClose}
                className="w-full py-3.5 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white font-bold text-sm shadow-md transition-colors cursor-pointer"
              >
                Back to Sneaker Store
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
