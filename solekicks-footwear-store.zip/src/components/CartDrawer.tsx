import React, { useState } from 'react';
import { CartItem, CartTotals, PromoCode } from '../types';
import {
  X,
  Trash2,
  Plus,
  Minus,
  ShoppingBag,
  Truck,
  Tag,
  ArrowRight,
  ShieldCheck,
  Check,
} from 'lucide-react';
import { formatCurrency, validatePromoCode, FREE_SHIPPING_THRESHOLD } from '../utils/cart';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  totals: CartTotals;
  appliedPromo: PromoCode | null;
  onUpdateQuantity: (id: string, delta: number) => void;
  onRemoveItem: (id: string) => void;
  onApplyPromo: (promo: PromoCode | null) => void;
  onProceedToCheckout: () => void;
  onExploreFootwear: () => void;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  totals,
  appliedPromo,
  onUpdateQuantity,
  onRemoveItem,
  onApplyPromo,
  onProceedToCheckout,
  onExploreFootwear,
}) => {
  const [promoInput, setPromoInput] = useState('');
  const [promoError, setPromoError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleApplyPromo = (e: React.FormEvent) => {
    e.preventDefault();
    setPromoError(null);
    if (!promoInput.trim()) return;

    const result = validatePromoCode(promoInput, totals.subtotal);
    if (result.valid && result.promo) {
      onApplyPromo(result.promo);
      setPromoInput('');
    } else {
      setPromoError(result.error || 'Invalid coupon code');
    }
  };

  const freeShippingProgress = Math.min(100, (totals.subtotal / FREE_SHIPPING_THRESHOLD) * 100);

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="cart-drawer-heading"
      className="fixed inset-0 z-50 overflow-hidden bg-neutral-950/60 backdrop-blur-xs flex justify-end animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col justify-between overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Drawer Header */}
        <div className="p-4 sm:p-5 border-b border-neutral-200 flex items-center justify-between bg-neutral-50/70">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-red-600 text-white flex items-center justify-center shadow-xs">
              <ShoppingBag className="w-4 h-4" />
            </div>
            <div>
              <h2 id="cart-drawer-heading" className="font-display font-extrabold text-lg text-neutral-900 leading-tight">
                Your Shopping Bag
              </h2>
              <p className="text-xs text-neutral-500 font-medium">
                {totals.itemsCount} {totals.itemsCount === 1 ? 'pair' : 'pairs'} selected
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-neutral-400 hover:text-neutral-700 hover:bg-neutral-200/60 rounded-full transition-colors cursor-pointer"
            aria-label="Close cart"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Free Shipping Progress Indicator */}
        <div className="px-4 py-3 bg-red-50/60 border-b border-red-100/80">
          <div className="flex items-center justify-between text-xs font-semibold mb-1.5 text-neutral-800">
            <span className="flex items-center gap-1.5">
              <Truck className="w-4 h-4 text-red-600" />
              {totals.freeShippingQualified ? (
                <span className="text-emerald-700 font-bold">You unlocked FREE standard shipping! 🎉</span>
              ) : (
                <span>
                  Add <strong className="text-red-600">{formatCurrency(totals.amountNeededForFreeShipping)}</strong> more for FREE Shipping
                </span>
              )}
            </span>
            <span className="text-[11px] font-bold text-neutral-500">
              {Math.round(freeShippingProgress)}%
            </span>
          </div>
          <div className="w-full bg-neutral-200 rounded-full h-1.5 overflow-hidden">
            <div
              className={`h-full transition-all duration-500 rounded-full ${
                totals.freeShippingQualified ? 'bg-emerald-500' : 'bg-red-600'
              }`}
              style={{ width: `${freeShippingProgress}%` }}
            />
          </div>
        </div>

        {/* Cart Items List */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {items.length === 0 ? (
            <div className="text-center py-16 px-4 space-y-4">
              <div className="w-16 h-16 mx-auto rounded-full bg-red-50 text-red-600 flex items-center justify-center">
                <ShoppingBag className="w-8 h-8 stroke-[1.5]" />
              </div>
              <div>
                <h3 className="font-display font-bold text-lg text-neutral-800">Your bag is empty</h3>
                <p className="text-xs text-neutral-500 mt-1 max-w-xs mx-auto">
                  Looks like you haven't added any fresh kicks to your cart yet.
                </p>
              </div>
              <button
                onClick={() => {
                  onClose();
                  onExploreFootwear();
                }}
                className="px-6 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 text-white font-bold text-xs shadow-md active:scale-95 transition-all cursor-pointer"
              >
                Explore Footwear
              </button>
            </div>
          ) : (
            items.map((item) => (
              <div
                key={item.id}
                className="flex gap-3.5 p-3 rounded-2xl bg-neutral-50/80 border border-neutral-200/80 hover:border-neutral-300 transition-colors"
              >
                {/* Thumbnail */}
                <div className="w-20 h-20 rounded-xl bg-white border border-neutral-200 overflow-hidden shrink-0">
                  <img
                    src={item.product.heroImage}
                    alt={item.product.name}
                    className="w-full h-full object-cover"
                  />
                </div>

                {/* Details */}
                <div className="flex-1 flex flex-col justify-between">
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <span className="text-[10px] font-bold uppercase tracking-wider text-neutral-400">
                        {item.product.brand}
                      </span>
                      <h4 className="font-display font-bold text-xs sm:text-sm text-neutral-900 line-clamp-1">
                        {item.product.name}
                      </h4>
                      <p className="text-[11px] text-neutral-500 font-medium">
                        Size: <strong className="text-neutral-800">US {item.selectedSize}</strong> • {item.selectedColor}
                      </p>
                    </div>

                    <button
                      onClick={() => onRemoveItem(item.id)}
                      className="text-neutral-400 hover:text-red-600 p-1 transition-colors cursor-pointer"
                      aria-label={`Remove ${item.product.name} from bag`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Quantity and Price */}
                  <div className="flex items-center justify-between mt-2 pt-1.5 border-t border-neutral-200/60">
                    <div className="flex items-center border border-neutral-300 rounded-lg bg-white overflow-hidden shadow-2xs">
                      <button
                        onClick={() => onUpdateQuantity(item.id, -1)}
                        className="p-1 hover:bg-neutral-100 text-neutral-600 transition-colors"
                        aria-label="Decrease quantity"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="px-2 text-xs font-bold text-neutral-900">{item.quantity}</span>
                      <button
                        onClick={() => onUpdateQuantity(item.id, 1)}
                        className="p-1 hover:bg-neutral-100 text-neutral-600 transition-colors"
                        aria-label="Increase quantity"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>

                    <span className="font-display font-extrabold text-sm text-neutral-900">
                      {formatCurrency(item.product.price * item.quantity)}
                    </span>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer Summary & Checkout (Only if items exist) */}
        {items.length > 0 && (
          <div className="p-4 sm:p-5 border-t border-neutral-200 bg-white space-y-3 shadow-lg">
            {/* Promo Code Input */}
            <form onSubmit={handleApplyPromo} className="space-y-1">
              <div className="flex gap-2">
                <div className="relative flex-1">
                  <Tag className="w-3.5 h-3.5 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="text"
                    placeholder="Promo code (e.g. KICKS20)"
                    value={promoInput}
                    onChange={(e) => setPromoInput(e.target.value)}
                    className="w-full bg-neutral-50 border border-neutral-200 text-xs font-medium rounded-xl pl-8 pr-3 py-2 uppercase placeholder:normal-case focus:outline-none focus:ring-2 focus:ring-red-500"
                  />
                </div>
                <button
                  type="submit"
                  className="px-3.5 py-2 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white text-xs font-bold transition-colors cursor-pointer shrink-0"
                >
                  Apply
                </button>
              </div>

              {promoError && (
                <p className="text-[11px] text-red-600 font-semibold">{promoError}</p>
              )}

              {appliedPromo && (
                <div className="flex items-center justify-between bg-emerald-50 text-emerald-800 px-2.5 py-1 rounded-lg text-xs font-bold border border-emerald-200">
                  <span className="flex items-center gap-1">
                    <Check className="w-3.5 h-3.5 text-emerald-600" />
                    {appliedPromo.code} applied ({appliedPromo.description})
                  </span>
                  <button
                    type="button"
                    onClick={() => onApplyPromo(null)}
                    className="text-emerald-700 hover:text-red-600 underline font-semibold ml-2 cursor-pointer"
                  >
                    Remove
                  </button>
                </div>
              )}
            </form>

            {/* Calculations Breakdown */}
            <div className="space-y-1.5 text-xs text-neutral-600 pt-2 border-t border-neutral-100">
              <div className="flex justify-between">
                <span>Subtotal</span>
                <span className="font-semibold text-neutral-800">{formatCurrency(totals.subtotal)}</span>
              </div>

              {totals.discountAmount > 0 && (
                <div className="flex justify-between text-red-600 font-semibold">
                  <span>Promo Discount ({appliedPromo?.code})</span>
                  <span>-{formatCurrency(totals.discountAmount)}</span>
                </div>
              )}

              <div className="flex justify-between">
                <span>Estimated Standard Shipping</span>
                <span className="font-semibold text-neutral-800">
                  {totals.shipping === 0 ? (
                    <span className="text-emerald-600 font-bold uppercase tracking-wider text-[11px]">Free</span>
                  ) : (
                    formatCurrency(totals.shipping)
                  )}
                </span>
              </div>

              <div className="flex justify-between">
                <span>Estimated Sales Tax (8%)</span>
                <span className="font-semibold text-neutral-800">{formatCurrency(totals.tax)}</span>
              </div>

              <div className="flex justify-between text-sm sm:text-base font-extrabold text-neutral-900 pt-2 border-t border-neutral-200">
                <span>Estimated Total</span>
                <span className="text-red-600 font-display text-lg">{formatCurrency(totals.total)}</span>
              </div>
            </div>

            {/* Checkout CTA */}
            <button
              onClick={onProceedToCheckout}
              className="w-full py-3.5 rounded-xl bg-gradient-to-r from-red-600 to-rose-600 hover:from-red-500 hover:to-rose-500 text-white font-extrabold text-sm sm:text-base shadow-lg shadow-red-600/30 flex items-center justify-center gap-2 active:scale-98 transition-all cursor-pointer"
              aria-label="Proceed to checkout"
            >
              <span>Proceed to Checkout</span>
              <ArrowRight className="w-4 h-4 stroke-[2.5]" />
            </button>

            <div className="flex items-center justify-center gap-2 text-[10px] text-neutral-400">
              <ShieldCheck className="w-3.5 h-3.5 text-blue-500" />
              <span>256-Bit SSL Encrypted Checkout</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
