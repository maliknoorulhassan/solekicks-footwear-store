import React from 'react';
import { Product } from '../types';
import { X, Heart, ShoppingBag, Trash2 } from 'lucide-react';
import { formatCurrency } from '../utils/cart';

interface WishlistDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  wishlist: Product[];
  onRemoveFromWishlist: (product: Product) => void;
  onSelectProduct: (product: Product) => void;
  onAddToCart: (product: Product, size: number, color: string) => void;
}

export const WishlistDrawer: React.FC<WishlistDrawerProps> = ({
  isOpen,
  onClose,
  wishlist,
  onRemoveFromWishlist,
  onSelectProduct,
  onAddToCart,
}) => {
  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="wishlist-heading"
      className="fixed inset-0 z-50 overflow-hidden bg-neutral-950/60 backdrop-blur-xs flex justify-end animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md bg-white h-full shadow-2xl flex flex-col justify-between overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-neutral-200 flex items-center justify-between bg-neutral-50/70">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-red-100 text-red-600 flex items-center justify-center">
              <Heart className="w-4 h-4 fill-red-600" />
            </div>
            <div>
              <h2 id="wishlist-heading" className="font-display font-bold text-lg text-neutral-900 leading-tight">
                Saved Footwear
              </h2>
              <p className="text-xs text-neutral-500">{wishlist.length} items in your wishlist</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-neutral-400 hover:text-neutral-700 hover:bg-neutral-200/60 rounded-full transition-colors cursor-pointer"
            aria-label="Close wishlist"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Wishlist Items List */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-3.5">
          {wishlist.length === 0 ? (
            <div className="text-center py-20 px-4 space-y-3">
              <div className="w-16 h-16 mx-auto rounded-full bg-rose-50 text-red-500 flex items-center justify-center">
                <Heart className="w-8 h-8" />
              </div>
              <h3 className="font-display font-bold text-lg text-neutral-800">Your wishlist is empty</h3>
              <p className="text-xs text-neutral-500 max-w-xs mx-auto">
                Tap the heart on any shoe to save it for later or track restocks!
              </p>
            </div>
          ) : (
            wishlist.map((product) => (
              <div
                key={product.id}
                className="flex gap-3.5 p-3 rounded-2xl bg-neutral-50 border border-neutral-200 hover:border-neutral-300 transition-colors"
              >
                <div
                  className="w-20 h-20 rounded-xl bg-white border border-neutral-200 overflow-hidden shrink-0 cursor-pointer"
                  onClick={() => {
                    onClose();
                    onSelectProduct(product);
                  }}
                >
                  <img src={product.heroImage} alt={product.name} className="w-full h-full object-cover" />
                </div>

                <div className="flex-1 flex flex-col justify-between">
                  <div className="flex items-start justify-between gap-1">
                    <div>
                      <span className="text-[10px] font-bold uppercase text-neutral-400">{product.brand}</span>
                      <h4
                        className="font-display font-bold text-xs sm:text-sm text-neutral-900 line-clamp-1 hover:text-red-600 cursor-pointer"
                        onClick={() => {
                          onClose();
                          onSelectProduct(product);
                        }}
                      >
                        {product.name}
                      </h4>
                      <p className="font-extrabold text-sm text-neutral-900 mt-0.5">
                        {formatCurrency(product.price)}
                      </p>
                    </div>

                    <button
                      onClick={() => onRemoveFromWishlist(product)}
                      className="text-neutral-400 hover:text-red-600 p-1 cursor-pointer"
                      aria-label={`Remove ${product.name} from wishlist`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>

                  <div className="flex items-center gap-2 mt-2">
                    <button
                      onClick={() => {
                        onAddToCart(product, product.sizes[0], product.colors[0].name);
                      }}
                      className="flex-1 py-1.5 px-3 rounded-xl bg-neutral-900 hover:bg-red-600 text-white text-xs font-bold transition-colors flex items-center justify-center gap-1.5 cursor-pointer shadow-xs"
                    >
                      <ShoppingBag className="w-3.5 h-3.5" />
                      <span>Add to Bag</span>
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-neutral-200 bg-neutral-50">
          <button
            onClick={onClose}
            className="w-full py-3 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white font-bold text-xs transition-colors cursor-pointer"
          >
            Continue Browsing
          </button>
        </div>
      </div>
    </div>
  );
};
