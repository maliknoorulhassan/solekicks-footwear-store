import React from 'react';
import { Order } from '../types';
import { X, Package, Truck, CheckCircle2, Clock } from 'lucide-react';
import { formatCurrency } from '../utils/cart';

interface OrdersDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  orders: Order[];
}

export const OrdersDrawer: React.FC<OrdersDrawerProps> = ({
  isOpen,
  onClose,
  orders,
}) => {
  if (!isOpen) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="orders-heading"
      className="fixed inset-0 z-50 overflow-hidden bg-neutral-950/60 backdrop-blur-xs flex justify-end animate-in fade-in duration-200"
      onClick={onClose}
    >
      <div
        className="w-full max-w-lg bg-white h-full shadow-2xl flex flex-col justify-between overflow-hidden"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-neutral-200 flex items-center justify-between bg-neutral-50/70">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-blue-100 text-blue-600 flex items-center justify-center">
              <Package className="w-4 h-4" />
            </div>
            <div>
              <h2 id="orders-heading" className="font-display font-bold text-lg text-neutral-900 leading-tight">
                Order Tracking
              </h2>
              <p className="text-xs text-neutral-500">Track shipments and view past receipts</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-neutral-400 hover:text-neutral-700 hover:bg-neutral-200/60 rounded-full transition-colors cursor-pointer"
            aria-label="Close orders drawer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Orders List */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4">
          {orders.length === 0 ? (
            <div className="text-center py-20 px-4 space-y-3">
              <div className="w-16 h-16 mx-auto rounded-full bg-blue-50 text-blue-500 flex items-center justify-center">
                <Truck className="w-8 h-8" />
              </div>
              <h3 className="font-display font-bold text-lg text-neutral-800">No orders placed yet</h3>
              <p className="text-xs text-neutral-500 max-w-xs mx-auto">
                Once you purchase footwear from SoleKicks, real-time dispatch and delivery updates will appear right here!
              </p>
            </div>
          ) : (
            orders.map((order) => (
              <div
                key={order.id}
                className="p-4 rounded-2xl bg-neutral-50 border border-neutral-200 space-y-3"
              >
                <div className="flex items-center justify-between border-b border-neutral-200 pb-2.5">
                  <div>
                    <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block">
                      Order ID
                    </span>
                    <span className="font-mono font-bold text-xs text-red-600">{order.id}</span>
                  </div>
                  <div className="text-right">
                    <span className="text-[10px] text-neutral-400 block">{order.createdAt}</span>
                    <span className="inline-flex items-center gap-1 text-[11px] font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">
                      <CheckCircle2 className="w-3 h-3" /> {order.status}
                    </span>
                  </div>
                </div>

                {/* Tracking status bar */}
                <div className="bg-white p-3 rounded-xl border border-neutral-200/80 space-y-1.5">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-neutral-600 flex items-center gap-1">
                      <Truck className="w-3.5 h-3.5 text-blue-600" /> Tracking Number:
                    </span>
                    <span className="font-mono font-bold text-neutral-800 text-[11px]">{order.trackingNumber}</span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-neutral-500">
                    <span>ETA: {order.estimatedDelivery}</span>
                    <span className="text-emerald-600 font-semibold">In Transit</span>
                  </div>
                </div>

                {/* Items preview */}
                <div className="space-y-2 pt-1">
                  {order.items.map((item) => (
                    <div key={item.id} className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-2">
                        <img src={item.product.heroImage} alt="" className="w-8 h-8 rounded-lg object-cover" />
                        <div>
                          <p className="font-bold text-neutral-900 truncate max-w-[200px]">{item.product.name}</p>
                          <p className="text-[10px] text-neutral-500">
                            Size US {item.selectedSize} • Qty {item.quantity}
                          </p>
                        </div>
                      </div>
                      <span className="font-bold text-neutral-900">
                        {formatCurrency(item.product.price * item.quantity)}
                      </span>
                    </div>
                  ))}
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-neutral-200 text-xs font-bold text-neutral-900">
                  <span>Total Paid ({order.paymentMethod.toUpperCase()}):</span>
                  <span className="text-sm font-extrabold text-red-600">{formatCurrency(order.totals.total)}</span>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-neutral-200 bg-neutral-50">
          <button
            onClick={onClose}
            className="w-full py-3 rounded-xl bg-neutral-900 hover:bg-neutral-800 text-white font-bold text-xs transition-colors cursor-pointer"
          >
            Close Orders
          </button>
        </div>
      </div>
    </div>
  );
};
