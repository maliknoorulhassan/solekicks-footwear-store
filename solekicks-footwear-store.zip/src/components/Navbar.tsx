import React from 'react';
import { ShoppingBag, Heart, Search, Footprints, ShieldCheck, Truck, Sparkles, X } from 'lucide-react';
import { formatCurrency } from '../utils/cart';

interface NavbarProps {
  cartCount: number;
  cartTotal: number;
  wishlistCount: number;
  onOpenCart: () => void;
  onOpenWishlist: () => void;
  onOpenOrders: () => void;
  searchQuery: string;
  onSearchChange: (query: string) => void;
  activeCategory: string;
  onSelectCategory: (category: any) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  cartCount,
  cartTotal,
  wishlistCount,
  onOpenCart,
  onOpenWishlist,
  onOpenOrders,
  searchQuery,
  onSearchChange,
  activeCategory,
  onSelectCategory,
}) => {
  return (
    <header className="sticky top-0 z-40 w-full shadow-lg">
      {/* Top Announcement Bar */}
      <div className="bg-neutral-950 text-white text-xs py-1.5 px-4 font-medium tracking-wide flex items-center justify-between border-b border-neutral-800">
        <div className="container mx-auto flex items-center justify-between">
          <div className="flex items-center space-x-2 text-neutral-300">
            <span className="inline-flex items-center px-1.5 py-0.5 rounded text-[10px] font-bold bg-red-600 text-white uppercase tracking-wider animate-pulse">
              HOT DROP
            </span>
            <span className="hidden sm:inline">Use coupon</span>
            <span className="font-bold text-amber-300 underline decoration-amber-400">KICKS20</span>
            <span>for 20% OFF all sneakers!</span>
          </div>
          <div className="flex items-center space-x-4 text-neutral-400 text-[11px]">
            <span className="hidden md:flex items-center gap-1 text-emerald-400">
              <Truck className="w-3.5 h-3.5" /> Free US Shipping on $150+
            </span>
            <span className="hidden lg:flex items-center gap-1 text-neutral-300">
              <ShieldCheck className="w-3.5 h-3.5 text-blue-400" /> 100% Verified Authentic
            </span>
            <button
              onClick={onOpenOrders}
              className="text-neutral-200 hover:text-white underline cursor-pointer transition-colors"
            >
              Track Order
            </button>
          </div>
        </div>
      </div>

      {/* Main Colored Navbar - Rich Gradient Styling as Requested */}
      <nav className="bg-gradient-to-r from-red-600 via-rose-600 to-red-700 text-white px-4 py-3 sm:py-3.5 transition-all">
        <div className="container mx-auto flex items-center justify-between gap-3 md:gap-6">
          {/* Brand Logo */}
          <button
            onClick={() => {
              onSelectCategory('All');
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            className="flex items-center gap-2.5 group cursor-pointer text-left focus:outline-none focus:ring-2 focus:ring-white/50 rounded-lg p-1"
            aria-label="SoleKicks Home"
          >
            <div className="w-10 h-10 rounded-xl bg-white text-red-600 flex items-center justify-center shadow-md shadow-red-900/40 group-hover:scale-105 transition-transform">
              <Footprints className="w-6 h-6 stroke-[2.5]" />
            </div>
            <div>
              <div className="font-display font-extrabold text-xl sm:text-2xl tracking-tighter leading-none flex items-center gap-1">
                <span>SOLE</span>
                <span className="text-amber-300">KICKS</span>
              </div>
              <p className="text-[10px] font-semibold text-rose-100 uppercase tracking-widest hidden sm:block">
                Premium Footwear Studio
              </p>
            </div>
          </button>

          {/* Desktop & Tablet Search Bar */}
          <div className="flex-1 max-w-md mx-2 relative hidden sm:block">
            <div className="relative">
              <Search className="w-4 h-4 text-neutral-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              <input
                type="text"
                placeholder="Search Jordan, Samba, Ultraboost, running shoes..."
                value={searchQuery}
                onChange={(e) => onSearchChange(e.target.value)}
                className="w-full bg-white text-neutral-900 placeholder:text-neutral-400 text-sm rounded-full pl-10 pr-9 py-2 focus:outline-none focus:ring-2 focus:ring-amber-300 shadow-inner font-medium"
              />
              {searchQuery && (
                <button
                  onClick={() => onSearchChange('')}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-700 p-0.5 rounded-full"
                  aria-label="Clear search"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>

          {/* Right Action Icons */}
          <div className="flex items-center space-x-1.5 sm:space-x-3">
            {/* Wishlist Button */}
            <button
              onClick={onOpenWishlist}
              className="relative p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition-all duration-200 active:scale-95 flex items-center gap-1.5"
              aria-label={`Wishlist with ${wishlistCount} items`}
            >
              <Heart className={`w-5 h-5 ${wishlistCount > 0 ? 'fill-amber-300 text-amber-300' : 'text-white'}`} />
              <span className="hidden md:inline text-xs font-semibold">Wishlist</span>
              {wishlistCount > 0 && (
                <span className="absolute -top-1.5 -right-1.5 bg-amber-400 text-neutral-950 text-[10px] font-extrabold w-5 h-5 rounded-full flex items-center justify-center shadow-md animate-bounce">
                  {wishlistCount}
                </span>
              )}
            </button>

            {/* Cart Button in Navbar */}
            <button
              onClick={onOpenCart}
              className="relative p-2 sm:px-3.5 sm:py-2 rounded-xl bg-white text-red-600 hover:bg-neutral-50 shadow-md transition-all duration-200 active:scale-95 flex items-center gap-2 group cursor-pointer"
              aria-label={`Open shopping cart with ${cartCount} items, total ${formatCurrency(cartTotal)}`}
            >
              <div className="relative">
                <ShoppingBag className="w-5 h-5 text-red-600 group-hover:scale-110 transition-transform" />
                {cartCount > 0 && (
                  <span className="absolute -top-2 -right-2 bg-neutral-950 text-white text-[10px] font-black w-4.5 h-4.5 rounded-full flex items-center justify-center">
                    {cartCount}
                  </span>
                )}
              </div>
              <div className="hidden sm:flex flex-col text-left">
                <span className="text-[10px] uppercase font-bold text-neutral-500 leading-tight">Cart</span>
                <span className="text-xs font-extrabold text-neutral-900 leading-tight">
                  {cartCount > 0 ? formatCurrency(cartTotal) : 'Empty'}
                </span>
              </div>
            </button>
          </div>
        </div>

        {/* Mobile Search Bar - shown under brand on compact screens */}
        <div className="mt-2.5 sm:hidden">
          <div className="relative">
            <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              placeholder="Search kicks, brands, models..."
              value={searchQuery}
              onChange={(e) => onSearchChange(e.target.value)}
              className="w-full bg-white text-neutral-900 placeholder:text-neutral-400 text-xs rounded-xl pl-9 pr-8 py-2 focus:outline-none focus:ring-2 focus:ring-amber-300 font-medium shadow-inner"
            />
            {searchQuery && (
              <button
                onClick={() => onSearchChange('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-neutral-700"
                aria-label="Clear mobile search"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </nav>
    </header>
  );
};
