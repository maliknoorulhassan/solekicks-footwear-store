import React from 'react';
import { ShoppingBag, ArrowRight } from 'lucide-react';
import { formatCurrency } from '../utils/cart';

interface FloatingCartButtonProps {
  cartCount: number;
  cartTotal: number;
  onOpenCart: () => void;
}

export const FloatingCartButton: React.FC<FloatingCartButtonProps> = ({
  cartCount,
  cartTotal,
  onOpenCart,
}) => {
  return (
    <aside aria-label="Floating cart action">
      <button
        onClick={onOpenCart}
        className="fixed bottom-22 md:bottom-8 right-3.5 md:right-8 z-30 group flex items-center gap-2.5 bg-gradient-to-r from-red-600 via-rose-600 to-red-600 text-white p-2.5 md:px-5 md:py-3.5 rounded-full shadow-2xl hover:shadow-red-500/50 hover:scale-105 active:scale-95 transition-all duration-300 border-2 border-white/20 cursor-pointer animate-float-bob"
        aria-label={`Open quick cart with ${cartCount} items, total ${formatCurrency(cartTotal)}`}
      >
        <div className="relative">
          <ShoppingBag className="w-5 h-5 md:w-6 md:h-6 text-white stroke-[2.2]" />
          {cartCount > 0 && (
            <span className="absolute -top-2 -right-2 bg-amber-400 text-neutral-950 font-black text-[10px] md:text-[11px] min-w-4.5 h-4.5 md:min-w-5 md:h-5 px-1 rounded-full flex items-center justify-center shadow-md animate-pulse">
              {cartCount}
            </span>
          )}
        </div>

        <div className="hidden sm:flex flex-col text-left">
          <span className="text-[10px] font-bold text-rose-100 uppercase tracking-wider">Quick Cart</span>
          <span className="text-sm font-extrabold text-white">
            {cartCount > 0 ? formatCurrency(cartTotal) : 'View Bag'}
          </span>
        </div>

        <div className="hidden sm:flex items-center justify-center w-7 h-7 rounded-full bg-white/20 group-hover:bg-white text-white group-hover:text-red-600 transition-colors ml-1">
          <ArrowRight className="w-4 h-4 stroke-[2.5]" />
        </div>
      </button>
    </aside>
  );
};
