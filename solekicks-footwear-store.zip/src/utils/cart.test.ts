import test from 'node:test';
import assert from 'node:assert/strict';
import {
  calculateCartTotals,
  validatePromoCode,
  filterAndSortProducts,
  PROMO_CODES,
  FREE_SHIPPING_THRESHOLD,
} from './cart';
import { CartItem, Product } from '../types';

const mockProduct: Product = {
  id: 'shoe-1',
  name: 'Nike Air Jordan 1 Retro',
  brand: 'Nike',
  category: 'Retro',
  price: 180,
  rating: 4.9,
  reviewCount: 320,
  inStock: 15,
  isFeatured: true,
  isNew: true,
  colors: [{ name: 'Chicago Red', hex: '#DC2626' }],
  sizes: [8, 9, 10, 11],
  heroImage: 'https://example.com/shoe.jpg',
  gallery: ['https://example.com/shoe.jpg'],
  description: 'Iconic high-top basketball sneaker.',
  specs: {
    cushioning: 'Air Sole',
    upperMaterial: 'Genuine Leather',
    weight: '430g',
    closure: 'Lace-up',
  },
};

const mockProduct2: Product = {
  id: 'shoe-2',
  name: 'Adidas Samba Classic',
  brand: 'Adidas',
  category: 'Classics',
  price: 100,
  rating: 4.7,
  reviewCount: 150,
  inStock: 8,
  isFeatured: false,
  isNew: false,
  colors: [{ name: 'Cloud White', hex: '#FFFFFF' }],
  sizes: [7, 8, 9],
  heroImage: 'https://example.com/samba.jpg',
  gallery: ['https://example.com/samba.jpg'],
  description: 'Indoor soccer legend turned streetwear staple.',
  specs: {
    cushioning: 'EVA Insole',
    upperMaterial: 'Full grain leather',
    weight: '340g',
    closure: 'Lace-up',
  },
};

test('calculateCartTotals calculates subtotal and qualifies for free shipping over threshold', () => {
  const items: CartItem[] = [
    {
      id: 'shoe-1-10-Chicago Red',
      product: mockProduct, // $180
      selectedSize: 10,
      selectedColor: 'Chicago Red',
      quantity: 1,
    },
  ];

  const totals = calculateCartTotals(items, null);
  assert.equal(totals.subtotal, 180);
  assert.equal(totals.itemsCount, 1);
  assert.equal(totals.freeShippingQualified, true);
  assert.equal(totals.shipping, 0);
  assert.equal(totals.tax, 14.4); // 8% of 180 = 14.4
  assert.equal(totals.total, 194.4);
});

test('calculateCartTotals adds standard shipping if below threshold', () => {
  const items: CartItem[] = [
    {
      id: 'shoe-2-8-Cloud White',
      product: mockProduct2, // $100
      selectedSize: 8,
      selectedColor: 'Cloud White',
      quantity: 1,
    },
  ];

  const totals = calculateCartTotals(items, null);
  assert.equal(totals.subtotal, 100);
  assert.equal(totals.freeShippingQualified, false);
  assert.equal(totals.shipping, 15);
  assert.equal(totals.amountNeededForFreeShipping, 50); // 150 - 100
  assert.equal(totals.tax, 8);
  assert.equal(totals.total, 123); // 100 + 15 + 8
});

test('calculateCartTotals applies KICKS20 percentage discount', () => {
  const items: CartItem[] = [
    {
      id: 'shoe-1-10-Chicago Red',
      product: mockProduct, // $180
      selectedSize: 10,
      selectedColor: 'Chicago Red',
      quantity: 1,
    },
  ];

  const totals = calculateCartTotals(items, PROMO_CODES['KICKS20']);
  assert.equal(totals.subtotal, 180);
  assert.equal(totals.discountAmount, 36); // 20% of 180
  // Taxable: 180 - 36 = 144
  // Tax: 144 * 0.08 = 11.52
  // Free shipping still qualifies because subtotal (180) >= 150
  assert.equal(totals.shipping, 0);
  assert.equal(totals.tax, 11.52);
  assert.equal(totals.total, 155.52);
});

test('validatePromoCode correctly identifies valid and invalid codes', () => {
  const validResult = validatePromoCode('kicks20', 100);
  assert.equal(validResult.valid, true);
  assert.equal(validResult.promo?.discountPercent, 20);

  const invalidResult = validatePromoCode('NONEXISTENT', 100);
  assert.equal(invalidResult.valid, false);

  const vipUnderThreshold = validatePromoCode('VIP30', 150);
  assert.equal(vipUnderThreshold.valid, false);

  const vipAboveThreshold = validatePromoCode('VIP30', 250);
  assert.equal(vipAboveThreshold.valid, true);
});

test('filterAndSortProducts filters by brand and search', () => {
  const products = [mockProduct, mockProduct2];
  const filteredNike = filterAndSortProducts(products, {
    category: 'All',
    brand: 'Nike',
    search: '',
    maxPrice: 500,
    sort: 'featured',
  });
  assert.equal(filteredNike.length, 1);
  assert.equal(filteredNike[0].brand, 'Nike');

  const filteredSearch = filterAndSortProducts(products, {
    category: 'All',
    brand: 'All',
    search: 'soccer',
    maxPrice: 500,
    sort: 'featured',
  });
  assert.equal(filteredSearch.length, 1);
  assert.equal(filteredSearch[0].name, 'Adidas Samba Classic');
});
