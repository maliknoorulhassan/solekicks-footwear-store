import { CartItem, CartTotals, Product, ProductFilters, PromoCode } from '../types';

export const PROMO_CODES: Record<string, PromoCode> = {
  KICKS20: {
    code: 'KICKS20',
    discountPercent: 20,
    description: '20% off your entire footwear order',
  },
  SNEAKER10: {
    code: 'SNEAKER10',
    discountPercent: 10,
    description: '10% off for sneaker enthusiasts',
  },
  FREESHIP: {
    code: 'FREESHIP',
    discountPercent: 0,
    description: 'Free expedited standard shipping',
  },
  VIP30: {
    code: 'VIP30',
    discountPercent: 30,
    minSpend: 200,
    description: '30% off orders over $200',
  },
};

export const FREE_SHIPPING_THRESHOLD = 150;
export const STANDARD_SHIPPING_RATE = 15;
export const TAX_RATE = 0.08; // 8%

export function calculateCartTotals(
  items: CartItem[],
  appliedPromo?: PromoCode | null
): CartTotals {
  const itemsCount = items.reduce((acc, item) => acc + item.quantity, 0);
  const rawSubtotal = items.reduce(
    (acc, item) => acc + item.product.price * item.quantity,
    0
  );
  const subtotal = Math.round(rawSubtotal * 100) / 100;

  let discountAmount = 0;
  let forceFreeShipping = false;

  if (appliedPromo) {
    if (appliedPromo.code === 'FREESHIP') {
      forceFreeShipping = true;
    } else if (
      !appliedPromo.minSpend ||
      subtotal >= appliedPromo.minSpend
    ) {
      discountAmount = Math.round(subtotal * (appliedPromo.discountPercent / 100) * 100) / 100;
    }
  }

  const freeShippingQualified = forceFreeShipping || subtotal >= FREE_SHIPPING_THRESHOLD;
  const shipping = itemsCount === 0 ? 0 : freeShippingQualified ? 0 : STANDARD_SHIPPING_RATE;
  const taxableAmount = Math.max(0, subtotal - discountAmount);
  const tax = Math.round(taxableAmount * TAX_RATE * 100) / 100;
  const total = Math.max(0, Math.round((taxableAmount + shipping + tax) * 100) / 100);

  const amountNeededForFreeShipping = Math.max(
    0,
    Math.round((FREE_SHIPPING_THRESHOLD - subtotal) * 100) / 100
  );

  return {
    subtotal,
    discountAmount,
    shipping,
    tax,
    total,
    itemsCount,
    freeShippingQualified,
    amountNeededForFreeShipping,
  };
}

export function validatePromoCode(
  code: string,
  subtotal: number
): { valid: boolean; promo?: PromoCode; error?: string } {
  const normalized = code.trim().toUpperCase();
  const found = PROMO_CODES[normalized];

  if (!found) {
    return { valid: false, error: 'Invalid coupon code. Try KICKS20 or FREESHIP.' };
  }

  if (found.minSpend && subtotal < found.minSpend) {
    return {
      valid: false,
      error: `Coupon ${found.code} requires a minimum order of $${found.minSpend}.`,
    };
  }

  return { valid: true, promo: found };
}

export function filterAndSortProducts(
  products: Product[],
  filters: ProductFilters
): Product[] {
  let result = [...products];

  // Category filter
  if (filters.category && filters.category !== 'All') {
    result = result.filter((p) => p.category === filters.category);
  }

  // Brand filter
  if (filters.brand && filters.brand !== 'All') {
    result = result.filter(
      (p) => p.brand.toLowerCase() === filters.brand.toLowerCase()
    );
  }

  // Search keyword filter
  if (filters.search && filters.search.trim().length > 0) {
    const q = filters.search.toLowerCase().trim();
    result = result.filter(
      (p) =>
        p.name.toLowerCase().includes(q) ||
        p.brand.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q)
    );
  }

  // Price cap
  if (filters.maxPrice && filters.maxPrice > 0) {
    result = result.filter((p) => p.price <= filters.maxPrice);
  }

  // Size filter
  if (filters.selectedSize) {
    result = result.filter((p) => p.sizes.includes(filters.selectedSize!));
  }

  // Sorting
  switch (filters.sort) {
    case 'price-asc':
      result.sort((a, b) => a.price - b.price);
      break;
    case 'price-desc':
      result.sort((a, b) => b.price - a.price);
      break;
    case 'rating':
      result.sort((a, b) => b.rating - a.rating);
      break;
    case 'newest':
      result.sort((a, b) => (b.isNew ? 1 : 0) - (a.isNew ? 1 : 0));
      break;
    case 'featured':
    default:
      result.sort((a, b) => (b.isFeatured ? 1 : 0) - (a.isFeatured ? 1 : 0));
      break;
  }

  return result;
}

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount);
}
